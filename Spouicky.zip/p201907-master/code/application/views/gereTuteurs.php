<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<title>
			Gérer les tuteurs – Spouicky
		</title>
		<link rel="stylesheet" type="text/css" href="<?= base_url() ?>/asset/css/style.css" />
		<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url() ?>/asset/image/tortue.gif" />
	</head>
	<body>

	<header>
		<div class="nav">
			<a href="<?= base_url() ?>index.php/tortue/accueilUser" class="navbtn">Accueil</a>
			<a href="<?= base_url() ?>index.php/tortue/deconnexion" class="navbtn">Déconnexion</a>
				<div style="float:right">
					<a href="<?= site_url() ?>/tortue/accueilUser" class="navbtn">Projets</a>
					<a href="<?= site_url() ?>/tortue/gereEtudiants" class="navbtn">Étudiants</a>
					<a href="<?= site_url() ?>/tortue/gereGroupes" class="navbtn">Groupes</a>
					<a href="<?= site_url() ?>/tortue/gereTuteurs" class="navbtn">Tuteurs</a>
				</div>
		</div>
	</header>

	<main>
		
		<div class="Centrer">
			<h1>Spouicky</h1>
			<h2>Gestion des projets de 2ème année</h2> 
		</div>

		<div class="centre">
			<div class="searchform">
				<?= form_open("tortue/gereTuteurs") ?>
					<input type="text" name="rech" id="rechercher" placeholder="Rechercher un tuteur" />
					<input type="submit" value="Valider" />
				<?= form_close() ?>
			</div>
		</div><?php

		if ($rec != "") { ?>
			<h2>Résultats de la recherche</h2><?php
			if (!empty($recTuteurs)) { ?>
				<table><?php
					foreach ($recTuteurs as $t) { ?>
						<tr>
							<td>
								<?= $t["nom"] ?>
							</td>
							<td>
								<?= $t["prenom"] ?>
							</td>
							<td>
								<?= form_open("tortue/suprTuteur") ?>
									<input type="hidden" value="<?= $t["id"] ?>" name="idtuteur" />
									<input type="submit" value="X" />
								<?= form_close() ?>
							</td>
						</tr><?php
					} ?>
			</table><?php
			}

			else
				echo "Aucun résultat n‘a été trouvé.";
		} ?>
		
	    <div class="centre">
			<h2>Ajouter des tuteurs</h2>
			<div class="searchform">
				<?= form_open("tortue/ajouterTuteur") ?>
					<input type="text" name="nom" placeholder="nom" />
					<input type="text" name="prenom" placeholder="prénom" />
					<input type="number" name="annee" placeholder="année" value="2020" />
					<input type="submit" value="Valider" />
				<?= form_close() ?>
			</div>
        </div>

        <div class="centre">
			<h2>Liste des tuteurs</h2>
			<table><?php
				foreach ($tuteurs as $t) { ?>
					<tr>
						<td>
							<?= $t["nom"] ?>
						</td>
						<td>
							<?= $t["prenom"] ?>
						</td>
						<td>
							<?= form_open("tortue/suprTuteur") ?>
								<input type="hidden" value="<?= $t["id"] ?>" name="idtuteur" />
								<input type="submit" value="X" />
							<?= form_close() ?>
						</td>
					</tr><?php
				} ?>
			</table>
		</div>
	</main>
</html>