<html>
	<head>
	<meta charset="utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<title>Créer un groupe – Spouicky</title>
		<link rel="stylesheet" type="text/css" href="<?= base_url() ?>/asset/css/style.css" />
		<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url() ?>/asset/image/tortue.gif" />
	</head>
		<body>

		<header>
			<div class="nav">
			 <a href="<?= base_url() ?>index.php/tortue/accueilUser" class="navbtn">Accueil</a>
			 <a href="<?= base_url() ?>index.php/tortue/monCompte" class="navbtn">Mon compte</a>
			 <a href="<?= base_url() ?>index.php/tortue/deconnexion" class="navbtn">Déconnexion</a>
			</div>
		</header>
		<main>
			<h1>
				Créer un groupe
			</h1>
		
			<div class="centre">
				<h1>
					Liste des étudiants
				</h1>
				<div class="searchform">
					<?= form_open("Groupe/creerGroupe") ?>
						<input type="text" name="rech" id="rechercher" placeholder="Quel étudiant rechercher vous ?" value="<?= $recherche ?? "" ?>">
						<input type="submit" value="Rechercher">
					<?= form_close() ?>
				</div>
			</div>

			<ul><?php
				foreach ($resultats as $res) { ?>
					<li>
						<?= $res["nom"] ?> <?= $res["prenom"] ?> <?= $res["groupeclasse"] ?>
						<?= form_open("Groupe/creerGroupe") ?>
							<input type="hidden" name="ajoutEtu" value="<?= $res["id"] ?>">
							<input type="submit" value="Ajouter dans la liste">
						<?= form_close() ?>
					</li><?php
				} ?>
			</ul>

			<ul><?php
				if ($groupeTempo != []) {
					   echo"<h1>Ma liste</h1>"; 
				}

				foreach ($groupeTempo as $r) { ?>
					<li>
						<?= $r["nom"] ?> <?= $r["prenom"] ?> <?= $r["groupeclasse"] ?>
						<?= form_open("Groupe/creerGroupe") ?>
							<input type="hidden" name="suprEtu" value="<?= $r["idinvite"] ?>">
							<input type="submit" value="Supprimer de la liste">
						<?= form_close() ?>
					</li><?php
				} ?>
			</ul>

			<div class="centre">
				<div class="searchform">
					<?= form_open("Groupe/creerGroupe") ?>
						<input type="hidden" name="valider" value="valide" />
						<input type="text" name="nomGroupe" minlength="3" maxlength="16" placeholder="Nom du groupe"/>
						<input type="submit" value="Valider" />
					<?= form_close() ?>
				</div>
			</div>
		</main>	
		<footer>
			<strong>© 2019<br>© Spouicky’s Group</strong>
		</footer>
	</body>
</html>