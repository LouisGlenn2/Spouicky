
		<h2>Invitations reçues</h2>

		<?php
			if ($estInvite) {
				foreach ($invitations as $invitation) { ?>
					   <figure class="cart">
					      <figcaption>
						       <div>
									Membres
									<br />
									<ul><?php
										foreach ($invitation["etudiants"] as $etudiant) { ?>
											<li><?= $etudiant["prenom"] . " " . $etudiant["nom"] ?></li><?php
										} ?>
									</ul>
								</div>
								<div class="nGroup">
									<?= $invitation["nomGroupe"] ?>
								</div>
							<div>
								<?= form_open("Groupe/refuserInvit") ?>
									<input type="hidden" name="idGroupe" value="<?= $invitation["idGroupe"] ?>" />
									<input type="submit" value="Refuser" />
								<?= form_close() ?>

								<?= form_open("Groupe/accepterInvit") ?>
									<input type="hidden" name="idGroupe" value="<?= $invitation["idGroupe"] ?>" />
									<input type="submit" value="Rejoindre" <?php if ($this->Donnees->estGroupePlein($invitation["idGroupe"]) || $this->Donnees->estDansGroupe($compte["id"])): ?> disabled="disabled" <?php endif; ?> />
								<?= form_close() ?>
							</div>
						</figcaption>
					</figure><?php
				}
			}

			else { ?>
				<p>
					Aucune invitation reçue.
				</p><?php
			}
