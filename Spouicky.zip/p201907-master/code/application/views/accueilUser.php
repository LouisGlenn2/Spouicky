<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<title>
			Accueil – Spouicky
		</title> 
		<link rel="stylesheet" type="text/css" href="<?= base_url() ?>/asset/css/style.css" />
		<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url() ?>/asset/image/tortue.gif" />
	</head>

	<body>
		<header>
			<div class="nav">
				 <a href="<?= site_url() ?>/tortue/monCompte" class="navbtn">Mon Compte</a>
				 <a href="<?= site_url() ?>/tortue/deconnexion" class="navbtn">Déconnexion</a>
			</div>
		</header>
		<main>
			<div class="Centrer">
				<h1>Spouicky</h1>
				<h2>Gestion des projets de 2e année</h2> 
			</div>

			<?php
				$this->load->view("recSujet", [ "rech" => $resultats, "id" => $compte["id"] ]);
			?>

			<div class="Centrer">
				<h1>Liste des sujets</h1><?php
				if ($infoMonProjet != null) { ?>
			                <div class="liste">
						Mon projet :
						<center>
							<img height="100em" align="center" src= <?= base_url() ?>/asset/image/spoui.png alt="&shy;" />
						</center>

						<a href="<?= site_url() ?>/sujet/voirSujet/<?= $infoMonProjet["idsujet"] ?>" class="btn">
							Voir
						</a>
					</div><?php
				}

				else if($infoMonSujet != null) { ?>
					<div class="liste">
						Je suis positionné sur :
						<br />
						<?= $infoMonSujet["titre"] ?>
						<br />
						<br />
						Proposé par <?= $infoMonSujet["nom"] ?> <?= $infoMonSujet["prenom"] ?>
						<br />
						<center>
							<img height="100em" align="center" src= <?= base_url() ?>/asset/image/spoui_or.png alt="&shy;" />
						</center>
						<a href="<?= site_url() ?>/sujet/voirSujet/<?= $infoMonSujet["idsujet"] ?>" class="btn">
							Voir
						</a>
					</div><?php
				}

				else { ?>
					<li class="liste">
						Pas de sujet
					</li><?php
				} ?>
			</div><?php
			$this->load->view("listeSujet", [
				"sujet" => $tousSujets,
			]); ?>
		</main>
		<footer>
			<strong>© 2020<br>© Spouicky’s Group</strong>
		</footer>
	</body>
</html>