<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<link rel="stylesheet" type="text/css" href="<?= base_url() ?>/asset/css/style.css" />
		<script type="text/javascript" src="<?= base_url() ?>/asset/js/js.js"></script>
		<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url() ?>/asset/image/tortue.gif" />
		<title>
			Spouicky
		</title> 
	</head>
	<body>
		<header>
			<h1>
				Spouicky
			</h1>
		</header>
		<main>
			<?= validation_errors() ?>
			<?= form_open("Tortue/connexion") ?>
				<div class="box">
					<h1>
						Connexion
					</h1>
					<input type="input" name="login" placeholder="pseudonyme" />
					<input type="password" name="motdepasse" placeholder="mot de passe" />
					<input type="submit" name="submit" value="Se connecter" />
				</div>
			<?= form_close() ?>
			<canvas class="zdog-canvas" width="320" height="280" />
		</main>
		<footer>
			<p>
				<strong>© 2020</strong>
			</p>
			<p>
				<strong>© Spouicky’s Group</strong>
			</p>
		</footer>
	</body>
</html>