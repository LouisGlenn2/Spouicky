<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<title>
			Mon Compte – Spouicky
		</title>
		<link rel="stylesheet" type="text/css" href="<?= base_url() ?>/asset/css/style.css" />
		<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url() ?>/asset/image/tortue.gif" />
	</head>
	<body>

	<header>
		<div class="nav">
			<a href="<?= base_url() ?>index.php/tortue/accueilUser" class="navbtn">Accueil</a>
			<a href="<?= base_url() ?>index.php/tortue/deconnexion" class="navbtn">Déconnexion</a>
		</div>
	</header>

	<main>
		<div class="Centrer"><?php
			if ($type == TYPE_ETUDIANT) { ?>
				<img alt="&shy;" class="avatar" src="<?= base_url() ?>asset/image/<?= $avatar ?>.png" />

				<?= form_open("Tortue/changerAvatar") ?>
					<br/>
					<select name="avatar">
						<option>newUser</option>
						<option>spoui_astro</option>
						<option>spoui_indi</option>
						<option>spoui_link</option>
						<option>spoui_luffy</option>
						<option>spoui_mili</option>
						<option>spoui_pirate</option>
						<option>spoui_zombi</option>
						<option>spoui_ferme</option>
						<option>spoui_deadpool</option>
						<option>spoui_avatar</option>
						<option>spoui_leonardo</option>
						<option>spoui_michel</option>
						<option>spoui_donatelo</option>
						<option>spoui_raphael</option>
					</select>
					<input type="submit" name="submitAv" value="Modifier mon Avatar" />
				<?= form_close() ?><?php
			} ?>

			<br />

			<h1>
				Bonjour <?= $compte["prenom"] . " " . $compte["nom"] ?>
			</h1>
			<h2 class="alignes">Identifiant : <?= $compte["login"] ?></h2>
			<h2 class="alignes">Mot de passe : ••••••</h2>
		</div>
		<div class="Centrer"><?php
			if (!$formmdp) { ?>
				<a href="<?= site_url() ?>/tortue/monCompte/true" class="btn">
					Modifier son mot de passe
				</a><?php
			}

			else { ?>
				<?= validation_errors() ?>

				<?= form_open("Tortue/modifierMotDePasse") ?>
					<div class="box">
						<h1>Modifier mon mot de passe :</h1>

						<input type="password" name ="motdepasse" placeholder="Mot de passe…" />
						<div>
							<input type="submit" name ="submit" value ="Valider" />

							<a href="<?= site_url() ?>/tortue/monCompte" class="btn">
								Annuler
							</a>
						<div>
					</div>
				<?= form_close() ?><?php
			} ?>
		</div>
