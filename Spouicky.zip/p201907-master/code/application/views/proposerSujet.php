<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<title>Proposer un sujet – Spouicky</title>
		<link rel="stylesheet" type="text/css" href="<?= base_url() ?>/asset/css/style.css" />
		<script type="text/javascript" src="<?= base_url() ?>/asset/js/js.js"></script>
		<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url() ?>/asset/image/tortue.gif" />
	</head>

	<?php
		if (!isset($sujet))
			$sujet = null;
	?>

	<body>
		<header>
			<div class="nav">
				<a href="<?= site_url() ?>/tortue/accueilUser" class="navbtn">Accueil</a>
				<a href="<?= site_url() ?>/tortue/monCompte" class="navbtn">Mon compte</a>
				<a href="<?= site_url() ?>/tortue/deconnexion" class="navbtn">Déconnexion</a>
			</div>
		</header>
		<main>
		<div class="Centrer"><?php
			if ($sujet == null) { ?>
				<h2>Proposer un sujet de projet</h2><?php
			}
			else { ?>
				<h2>Modifier le sujet de projet</h2><?php
			 } ?>
		</div>

		<?= validation_errors() ?><?php

		if ($sujet == null)
			echo form_open("Sujet/ProposerSujet");

		else
			echo form_open("Sujet/validerModifSujet"); ?>

			<div id="form-main">
			  <div id="form-div">
				<form class="form" id="form1">
					  <input type="hidden" name="idSujet" value="<?= $sujet["idsujet"] ?>">
					  <p class="intitule">
						<input name="intitule" type="input" class="feedback-input" placeholder="Intitulé" id="intitule" value="<?= $sujet["titre"] ?>"/>
					  </p>
					  <p class="description">
						<textarea name="description" type="input" class="feedback-input" id="comment" placeholder="Description"><?= $sujet["description"] ?></textarea>
					  </p>
					  <p class="tools">
						<input name="outil" type="input" class="feedback-input" id="outil" placeholder="Outils" value="<?= $sujet["outils"] ?>"/>
					  </p>
					  <div class="submit">
						<input type="submit" name="submit" value=" <?php if ($sujet == null) { echo "Poster"; } else { echo "Modifier"; } ?>" id="button-blue"/>
					  </div>
					</form>
				</div>
			</div>
		<?= form_close() ?>
	</main>
</body>