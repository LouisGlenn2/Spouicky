<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<title>Sujet – Spouicky</title>
		<link rel="stylesheet" type="text/css" href="<?= base_url() ?>/asset/css/style.css" />
		<script type="text/javascript" src="<?= base_url() ?>/asset/js/js.js"></script>
		<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url() ?>/asset/image/tortue.gif" />
	</head>
	<body>

	<header>
		<div class="nav">
			<a href="<?= base_url() ?>index.php/tortue/accueilUser" class="navbtn">Accueil</a>
			<a href="<?= base_url() ?>index.php/tortue/monCompte" class="navbtn">Mon compte</a>
			<a href="<?= base_url() ?>index.php/tortue/deconnexion" class="navbtn">Déconnexion</a>
		</div>
	</header>
	<body><?php
		$compte = $this->session->userdata("user");

		if ($compte == null)
			redirect("/tortue/connexion");

		$type = $this->Donnees->typeUtilisateur($compte["id"]); ?>

		<h1>
			<?= $sujetSelect["titre"] ?>
		</h1>

		<h2>
			Description
		</h2>

		<p>
			<?= $sujetSelect["description"] ?>
		</p>

		<h2>
			Logiciel/Langages
		</h2>

		<p>
			<?= $sujetSelect["outils"] ?>
		</p><?php

		if($sujetSelect["idcreateur"] == $compte["id"] || $this->Donnees->estSuperTuteur($compte["id"])){
			if(!$this->Donnees->estProjet($sujetSelect["idsujet"])){ ?>
				<a href="<?= site_url() ?>/Sujet/modifierSujet/<?= $sujetSelect["idsujet"] ?>" class="btn">
					Modifier ce sujet
				</a><?php
			}
		}

		if ($this->Donnees->estProjet($sujetSelect["idsujet"])) {
			$projet = $this->Donnees->getProjetSujetId($sujetSelect["idsujet"]);
			echo "Tuteur inscrit : " . $projet[0]["nomtuteur"] . " " . $projet[0]["prenomtuteur"]; ?>
			<h2>Groupe affecté</h2><?php
			$projet = $this->Donnees->projet($sujetSelect["idsujet"]);

			echo "<br>Nom du groupe : " . $projet["nomgroupe"] . "<br>";
			$membres = $this->Donnees->getEtudiantsGroupe($projet["idgroupe"]);

			foreach ($membres as $membre)
				echo $membre["nom"]." ".$membre["prenom"]."<br>";
				
			echo form_open("Sujet/annulerProjet") ?>
				<input type="hidden" name="idSujet" value="<?= $sujetSelect["idsujet"] ?>" />
				<input type="submit" value="Annuler le projet" />
			<?= form_close() ?><?php
		}
		else {
			echo "<h2>Tuteurs</h2>";
			if ($tuteurs == NULL) { ?>
				<p>
					Pas de tuteur pour le moment revener plus tard !
				</p><?php
			}
			else {
				echo "<ul>";
				foreach ($tuteurs as $tuteur) { ?>
					<?= "<li> " . $tuteur["nom"] . " " . $tuteur["prenom"] . "</li>" ?><?php
					if ($type == TYPE_SUPERTUTEUR) { ?>
						<?= form_open("Sujet/supprimerTuteurSujet") ?>
							<input type="hidden" name="idSujet" value="<?= $sujetSelect["idsujet"] ?>" />
							<input type="hidden" name="idTuteur" value="<?= $tuteur["idtuteur"] ?>" />
							<input type="submit" value="X" />
						<?= form_close() ?><?php
					}
				}
				echo "</ul>";
			} ?>
			<h2>Groupes inscrits</h2><?php
			foreach ($groupesSujet as $grp) { ?>
				<div style="border:1px dashed">
					<h3>
						Groupe : <?= $grp["nomgroupe"] ?>
					</h3><?php
					$membres = $this->Donnees->getEtudiantsGroupe($grp["idgroupe"]);

					echo "<ul>";
					foreach ($membres as $m)
						echo "<li>".$m["nom"]." ".$m["prenom"] . "</li>";
					echo "</ul>";

					if ($type == TYPE_SUPERTUTEUR) { ?>
						<?= form_open("Sujet/supprimerGroupeSujet") ?>
							<input type="hidden" name="idSujet" value="<?= $sujetSelect["idsujet"] ?>">
							<input type="hidden" name="idGroupe" value="<?= $grp["idgroupe"] ?>">
							<input type="submit" value="X">
						<?= form_close() ?><?php
					} ?>
				</div><?php
			}

			if ($type == TYPE_ETUDIANT) {
				$groupe = $this->Donnees->obtenirGroupe($compte["id"]);
				if ($groupe != null) {
					if (!$this->Donnees->estInscritSurSujet($groupe["idgroupe"], $sujetSelect["idsujet"])) {
						if ($this->Donnees->estInscritSujet($groupe["idgroupe"])) {
							echo "Vous êtes déjà sur un sujet !";
						}
						else { ?>
							<?= form_open("Sujet/inscrireSujet") ?>
								<input type="hidden" name="idSujet" value="<?= $sujetSelect["idsujet"] ?>">
								<input type="submit" value="S’inscrire sur ce sujet">
							<?= form_close() ?>

							<?php
						}
					}
					else { ?>
						<?= form_open("Sujet/desinscrireSujet") ?>
						<input type="hidden" name="idSujet" value="<?= $sujetSelect["idsujet"] ?>">
						<input type="submit" value="Se désinscrire du sujet">
						<?= form_close() ?><?php
					}
				} else {
					echo "Inscrivez-vous dans un groupe";
				}
			}
			else if ($type >= TYPE_TUTEUR) {
				if($sujetSelect["valide"] != "f" && !$this->Donnees->estProjet($sujetSelect["idsujet"])) {
					if(!$this->Donnees->estVolontaireSujet($compte["id"], $sujetSelect["idsujet"])){
						?>
						<?= form_open("Sujet/devenirVolontaireSujet") ?>
							<input type="hidden" name="idSujet" value="<?= $sujetSelect["idsujet"] ?>">
							<input type="submit" value="Se proposer volontaire">
						<?= form_close();
					}
					else { ?>
						<?= form_open("Sujet/annulerVolontaireSujet") ?>
							<input type="hidden" name="idSujet" value="<?= $sujetSelect["idsujet"] ?>">
							<input type="submit" value="Ne plus être volontaire">
						<?= form_close();
					}
				}
			}
			if ($type == TYPE_SUPERTUTEUR) {
				if ($sujetSelect["valide"] == "f") { ?>
					<?= form_open("Sujet/validerSujet") ?>
						<input type="hidden" name="idSujet" value="<?= $sujetSelect["idsujet"] ?>">
						<input type="submit" value="Valider le sujet">
					<?= form_close();
					
					form_open("Sujet/supprimerSujet") ?>
						<input type="hidden" name="idSujet" value="<?= $sujetSelect["idsujet"] ?>">
						<input type="submit" value="Supprimer le sujet">
					<?= form_close();
				}
				else {
					if ($this->Donnees->peutCreerProjet($sujetSelect["idsujet"])) { ?>
						<?= form_open("Sujet/creerProjet") ?>
							<input type="hidden" name="idSujet" value="<?= $sujetSelect["idsujet"] ?>">
							<div><?php
							$i = 0;
							foreach ($tuteurs as $tuteur) { ?>
								<label for="t<?= $tuteur["idtuteur"] ?>"><?= $tuteur["nom"] . " " . $tuteur["prenom"] ?></label>
								<input type="radio" id="t<?= $tuteur["idtuteur"] ?>" name="tuteur" value="<?= $tuteur["idtuteur"] ?>" <?php if ($i == 0) echo "checked"; ?>/><?php
								$i++;
							} ?>
							</div>
							<input type="submit" value="Créer le projet">
						<?= form_close() ?><?php
					} ?>
					<?= form_open("Sujet/annulerValidation") ?>
						<input type="hidden" name="idSujet" value="<?= $sujetSelect["idsujet"] ?>">
						<input type="submit" value="Annuler la validation du sujet">
					<?= form_close() ?><?php
				}
			}
		} ?>
	</body>
</html>