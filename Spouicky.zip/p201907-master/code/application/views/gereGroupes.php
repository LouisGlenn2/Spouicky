<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<title>
			Gérer les groupes – Spouicky
		</title>
		<link rel="stylesheet" type="text/css" href="<?= base_url() ?>/asset/css/style.css" />
		<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url() ?>/asset/image/tortue.gif" />
	</head>
	<body>

	<header>
		<div class="nav">
			<a href="<?= base_url() ?>index.php/tortue/accueilUser" class="navbtn">Accueil</a>
			<a href="<?= base_url() ?>index.php/tortue/deconnexion" class="navbtn">Déconnexion</a>
				<div style="float:right">
					<a href="<?= site_url() ?>/tortue/accueilUser" class="navbtn">Projets</a>
					<a href="<?= site_url() ?>/tortue/gereEtudiants" class="navbtn">Étudiants</a>
					<a href="<?= site_url() ?>/tortue/gereGroupes" class="navbtn">Groupes</a>
					<a href="<?= site_url() ?>/tortue/gereTuteurs" class="navbtn">Tuteurs</a>
				</div>
		</div>
	</header>

	<main>
		
		<div class="Centrer">
			<h1>Spouicky</h1>
			<h2>Gestion des projets de 2ème année</h2> 
		</div>

		<div class="centre">
			<div class="searchform">
				<?= form_open("tortue/gereGroupes") ?>
					<input type="text" name="rech" id="rechercher" placeholder="Rechercher un groupe" />
					<input type="submit" value="Valider" />
				<?= form_close() ?>
			</div>
		</div>
		
		<?php
		if ($rec != "") { ?>
			<h2>Résultats de la recherche</h2><?php
			if (!empty($recGroupes)) { ?>
				<table><?php
					foreach ($recGroupes as $e) { ?>
							<tr>
							<td>
								<?= $e["nomgroupe"] ?>
							</td>
							<td>
								<?= form_open("tortue/suprGroupe") ?>
									<input type="hidden" value="<?= $e["idgroupe"] ?>" name="idgroupe" />
									<input type="submit" value="X" />
								<?= form_close() ?>
							</td>
						</tr><?php
					} ?>
				</table><?php
			}

			else
				echo "Aucun résultat n‘a été trouvé.";
		} ?>
		
	    <div class="centre">
			<h2>Ajouter des groupes</h2>
			<div class="searchform">
				<?php echo form_open("tortue/ajouterGroupe") ?>
					<input type="text" name="nom" placeholder="nom" maxlength="20" />
					<input type="submit" value="Valider" />
				<?= form_close() ?>
			</div>
		</div>

		<div class="centre">
			<h2>Liste des groupes</h2>
			<table>
			<?php
				foreach ($groupes as $g) { ?>
					<tr>
						<td>
							<?= $g["nomgroupe"] ?>
						</td>
						<td>
							<?= form_open("tortue/suprGroupe") ?>
								<input type="hidden" value="<?= $g["idgroupe"] ?>" name="idgroupe" />
								<input type="submit" value="X" />
							<?= form_close() ?>
						</td>
					</tr><?php
				} ?>
			</table>
		</div>

	    <div class="centre">
			<h2>Affecter un groupe à un sujet</h2>
			<div class="searchform">
				<?= form_open("Sujet/affecterGroupe") ?>
					<label for="groupe">Le groupe </label>
					<select name="groupe" id="groupe"><?php
						foreach ($this->Donnees->groupesSansSujet() as $groupe) { ?>
							<option value="<?= $groupe["idgroupe"] ?>"><?= $groupe["nomgroupe"] ?></option><?php
						} ?>
					</select>
					<label for="sujet"> au sujet </label>
					<select name="sujet" id="sujet"><?php
						foreach ($this->Donnees->sujetsSansGroupe() as $sujet) { ?>
							<option value="<?= $sujet["idsujet"] ?>"><?= $sujet["titre"] ?></option><?php
						} ?>
					</select>
					<input type="submit" value="Affecter" />
				<?= form_close() ?>
			</div>
		</div>
	</main>
</html>