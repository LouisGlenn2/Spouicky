
			<div class="Centrer">
				<h1>Mon groupe : <?= $monGroupe["nomgroupe"] ?></h1>
				<ul class="grid">
				<?php
					foreach ($monGroupe["inscrits"] as $inscrit) { ?>
						 <li class="liste">
							<img alt="&shy;" style="margin-top:1em;height:7em" src="<?= base_url() ?>asset/image/<?= $inscrit["avatar"] ?>.png" />
							<br />
							 <?= $inscrit["nom"] ?> <?= $inscrit["prenom"] ?>
						 </li><?php
					} ?>
				 </ul>
			</div>
				 
			<div class="Centrer">
				<h2>
					Invitations envoyées
				</h2>
				<ul class="grid"><?php
					foreach ($monGroupe["invites"] as $invite) { ?>
						 <li class="liste">
							 <?= $invite["nom"] . " " . $invite["prenom"] ?>
							 <?= form_open("Groupe/supprimerInvit") ?>
								<input type="hidden" name="supprInvitEtu" value="<?= $invite["id"] ?>">
								<input type="submit" value="Annuler">
							<?= form_close() ?>
						 </li><?php
					 }
					 if (count($monGroupe["invites"]) == 0)
						echo "Aucune invitation en attente."; ?>
				 </ul>

				<?php if (!$this->Donnees->estGroupePlein($monGroupe["idgroupe"])): ?>
					<div class="centre">
						<h2>
							Inviter d’autres personnes
						</h2>
						<div class="searchform">
							<?= form_open("Tortue/monCompte") ?>
								<input type="text" name="rech" id="rechercher" placeholder="Quel étudiant recherchez-vous ?" value="<?= $recherche ?? "" ?>">
								<input type="submit" value="Rechercher">
							<?= form_close() ?>
						</div>

						<ul><?php
							foreach ($resultats as $res) { ?>
								<li>
									<?= $res["nom"] ?> <?= $res["prenom"] ?> <?= $res["groupeclasse"] ?>
									<?= form_open("Groupe/inviter") ?>
										<input type="hidden" name="ajoutEtu" value="<?= $res["id"] ?>">
										<input type="submit" value="+">
									<?= form_close() ?>
								</li><?php
							}
						?>
						</ul>
					</div>
				<?php endif; ?>

			  	<div>
					<?php
						$this->load->view("listeInvitations", [
							"compte" => $compte
						]);
					?>

					<?= form_open("Groupe/quitterGroupe") ?>
						<input onclick="return sure();" type="submit" name="submit" value="Quitter mon groupe" />

						<script>
							function sure () {
								return confirm("Êtes-vous sûr de vouloir quitter ce groupe ?")
							}
						</script>
					<?= form_close() ?>
				</div>
			</div>
		</main>
	</body>
</html>