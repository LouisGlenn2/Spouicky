
			<div class="Centrer">
				<h1>Je n’ai pas de groupe</h1>

				<?php
					$this->load->view("listeInvitations", [
						"compte" => $compte,
					]);
				?>
				<a href="<?= site_url() ?>/groupe/creerGroupe" class="navbtn">
					Créer un groupe
				</a>
			</div>
		 </main>
	</body>
</html>