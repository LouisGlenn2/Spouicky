<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<title>
			Accueil – Spouicky
		</title> 
		<link rel="stylesheet" type="text/css" href="<?= base_url() ?>/asset/css/style.css" />
		<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url() ?>/asset/image/tortue.gif" />
	</head>

	<body>
		<header>
			<div class="nav">
				<a href="<?= base_url() ?>index.php/tortue/monCompte" class="navbtn">Mon Compte</a>
				<a href="<?= base_url() ?>index.php/tortue/deconnexion" class="navbtn">Déconnexion</a>
			</div>
		</header>

		<main>
			<div class="Centrer">
				<h1>Spouicky</h1>
				<h2>Gestion des projets de 2ème année</h2> 
			</div><?php

			$this->load->view("recSujet", [ "rech" => $resultats, "id" => $compte["id"] ]);

			$data = array("sujet" => $this->Donnees->getListeVolontariats($compte["id"]));

			if ($data["sujet"] != null) { ?>
				<h1 class="Centrer">Liste de mes volontariats</h1><?php
				$this->load->view("listeSujet", $data);
			} ?>

			<h1 class="Centrer">Liste des sujets</h1><?php

			$this->load->view("listeSujet", [
				"sujet" => $tousSujets
			]); ?>
		</main>
		<footer>
			<strong>© 2020<br>© Spouicky’s Group</strong>
		</footer>
	</body>
</html>