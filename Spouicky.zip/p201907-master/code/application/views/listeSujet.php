	<div>
		<ul id="grid">
			<?php foreach($sujet as $item): ?>
				<li class="liste"><?php
					if (in_array($item["idsujet"], $numProjet[0])) { ?>
						Projet
						<br />
						<?= $item["titre"] ?>
						<br />
						<br />
						Proposé par <?= $item["nom"] ?> <?= $item["prenom"] ?>
						<br />
						<center>
							<img height="100em" align="center" src= <?= base_url() ?>/asset/image/spoui_red.png alt="Sujet occupé" />
						</center><?php
					}
					else { ?>
						Sujet <br />
						<?= $item["titre"] ?>
						<br />
						<br />
						Proposé par <?= $item["nom"] ?> <?= $item["prenom"] ?>
						<br />
						<center>
							<img height="100em" align="center" src= <?= base_url() ?>/asset/image/spoui_vert.png alt="Sujet accessible" />
						</center><?php
					} ?>
					<a href="<?= site_url() ?>/sujet/voirSujet/<?= $item["idsujet"] ?>" class="btn">
						Voir
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
