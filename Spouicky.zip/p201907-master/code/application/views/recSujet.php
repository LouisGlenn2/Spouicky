	<div class="centre">
		<div class="searchform">
			<?= form_open("tortue/accueilUser") ?>
				<input type="text" name="rechercher" id="rechercher" placeholder="Quel sujet recherchez-vous ?">
				<input type="submit" value="Valider">
			<?= form_close(); ?>
		</div>
		<?php
			$type = $this->Donnees->typeUtilisateur($id);
			$groupe = $this->Donnees->obtenirGroupe($id);

			if ($type >= TYPE_TUTEUR || ($type == TYPE_ETUDIANT && $groupe != null && !$this->Donnees->estInscritSujet($groupe["idgroupe"]) && !$this->Donnees->estInscritProjet($groupe["idgroupe"]))) { ?>
				<div>
					<a href="<?= site_url() ?>/sujet/proposerSujet" class="btn">Proposer un sujet</a>
				</div><?php
			}
		?>
	</div>
	<div class="Centrer"><?php
		if ($rech != []) { ?>
			<h1>
				Résultat de recherche
			</h1><?php
		} ?>
	</div><?php

	$this->load->view("listeSujet", [ "sujet" => $rech ]); ?>
