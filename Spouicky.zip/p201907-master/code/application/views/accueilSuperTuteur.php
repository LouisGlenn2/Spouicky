<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<title>
			Accueil – Spouicky
		</title> 
	   <link rel="stylesheet" type="text/css" href="<?= base_url() ?>/asset/css/style.css" />
		<script type="text/javascript" src="<?= base_url() ?>/asset/js/js.js"></script>
		<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url() ?>/asset/image/tortue.gif" />
	</head>

	<body>
		<header>
			<div class="nav">
				<a href="<?= site_url() ?>/tortue/monCompte" class="navbtn">Mon Compte</a>
				<a href="<?= site_url() ?>/tortue/deconnexion" class="navbtn">Déconnexion</a>
				<div style="float:right">
					<a href="<?= site_url() ?>/tortue/accueilUser" class="navbtn">Projets</a>
					<a href="<?= site_url() ?>/tortue/gereEtudiants" class="navbtn">Étudiants</a>
					<a href="<?= site_url() ?>/tortue/gereGroupes" class="navbtn">Groupes</a>
					<a href="<?= site_url() ?>/tortue/gereTuteurs" class="navbtn">Tuteurs</a>
				</div>
			</div>
		</header>
		<main>
			<div class="Centrer">
				<h1>Spouicky</h1>
				<h2>Gestion des projets de 2e année</h2> 
			</div>
			

			<?php
				$this->load->view("recSujet", [ "rech" => $resultats, "id" => $compte["id"] ] ); ?>

			<?php
				$data = [
					"sujet" => $this->Donnees->projets()
				];

				if($data["sujet"] != null){ ?>
					<h1 class="Centrer">Liste des projets</h1><?php
					$this->load->view("listeSujet", $data);
				} ?>

			<?php
				$data = [
					"sujet" => $this->Donnees->getListeSujetsNonValides()
				];

				if($data["sujet"] != null){ ?>
					<h1 class="Centrer">Sujets à valider</h1><?php
					$this->load->view("listeSujet", $data);
				} ?>
					
			<?php
				$data = [
					"sujet" => $this->Donnees->getListeVolontariats($compte["id"])
				];

				if ($data["sujet"] != null) { ?>
					<h1 class="Centrer">Liste de mes volontariats</h1><?php
					$this->load->view("listeSujet", $data);
				} ?>
		
			<h1 class="Centrer">
				Liste des sujets
			</h1>

			<?php
				$this->load->view("listeSujet", [
					"sujet" => $tousSujets,
				]);
			?>
		</main>
		<footer>
			<strong>© 2020<br>© Spouicky’s Group</strong>
		</footer>
	</body>
</html>