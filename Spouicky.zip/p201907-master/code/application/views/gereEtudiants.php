<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<title>
			Gérer les étudiants – Spouicky
		</title>
		<link rel="stylesheet" type="text/css" href="<?= base_url() ?>/asset/css/style.css" />
		<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url() ?>/asset/image/tortue.gif" />
	</head>
	<body>

	<header>
		<div class="nav">
			<a href="<?= base_url() ?>index.php/tortue/accueilUser" class="navbtn">Accueil</a>
			<a href="<?= base_url() ?>index.php/tortue/deconnexion" class="navbtn">Déconnexion</a>
				<div style="float:right">
					<a href="<?= site_url() ?>/tortue/accueilUser" class="navbtn">Projets</a>
					<a href="<?= site_url() ?>/tortue/gereEtudiants" class="navbtn">Étudiants</a>
					<a href="<?= site_url() ?>/tortue/gereGroupes" class="navbtn">Groupes</a>
					<a href="<?= site_url() ?>/tortue/gereTuteurs" class="navbtn">Tuteurs</a>
				</div>
		</div>
	</header>

	<main>
		
		<div class="Centrer">
			<h1>Spouicky</h1>
			<h2>Gestion des projets de 2ème année</h2> 
		</div>

		<div class="centre">
			<div class="searchform">
				<?= form_open("tortue/gereEtudiants") ?>
					<input type="text" name="rech" id="rechercher" placeholder="Rechercher un étudiant" />
					<input type="submit" value="Valider" />
				<?= form_close() ?>
			</div>
		</div>
		
		<?php
		if ($rec != "") { ?>
			<h2>Résultats de la recherche</h2><?php
			if (!empty($recEtu)) { ?>
				<table><?php
					foreach ($recEtu as $e) { ?>
							<tr>
							<td>
								<?= $e["nom"] ?>
							</td>
							<td>
								<?= $e["prenom"] ?>
							</td>
							<td>
								<?= form_open("tortue/suprEtu") ?>
									<input type="hidden" value="<?= $e["id"] ?>" name="idetu" />
									<input type="submit" value="X" />
								<?= form_close() ?>
							</td>
						</tr><?php
					} ?>
				</table><?php
			}

			else
				echo "Aucun résultat n‘a été trouvé.";
		} ?>

	    <div class="centre">
			<h2>Ajouter des étudiants</h2>
			<div class="searchform">
				<?php echo form_open("tortue/ajouterEtu") ?>
					<input type="text" name="nom" placeholder="nom" maxlength="20" />
					<input type="text" name="prenom" placeholder="prénom" maxlength="20" />
					<input type="number" name="annee" placeholder="année" maxlength="4" value="2020" />
					<input type="text" name="groupeClasse" placeholder="groupe" maxlength="2" />
					<input type="submit" value="Valider" />
				<?= form_close() ?>
			</div>
		</div>
		
	    <div class="centre">
			<h2>Liste des étudiants</h2>
			<table>
			<?php
				foreach ($etu as $e) { ?>
					<tr>
						<td>
							<?= $e["nom"] ?>
						</td>
						<td>
							<?= $e["prenom"] ?>
						</td>
						<td>
							<?= form_open("tortue/suprEtu") ?>
								<input type="hidden" value="<?= $e["id"] ?>" name="idetu" />
								<input type="submit" value="X" />
							<?= form_close() ?>
						</td>
					</tr><?php
				} ?>
			</table>
		</div>

	    <div class="centre">
			<h2>Affecter un étudiant à un groupe</h2>
			<div class="searchform">
				<?= form_open("Groupe/affecterEtu") ?>
					<label for="etu">L’étudiant </label>
					<select name="etu" id="etu"><?php
						foreach ($this->Donnees->etuSansGroupe() as $etu) { ?>
							<option value="<?= $etu["id"] ?>"><?= $etu["nom"] ?> <?= $etu["prenom"] ?></option><?php
						} ?>
					</select>
					<label for="groupe"> au groupe </label>
					<select name="groupe" id="groupe"><?php
						foreach ($this->Donnees->groupesIncomplets() as $groupe) { ?>
							<option value="<?= $groupe["idgroupe"] ?>"><?= $groupe["nomgroupe"] ?></option><?php
						} ?>
					</select>
					<input type="submit" value="Affecter" />
				<?= form_close() ?>
			</div>
		</div>
	</main>
</html>