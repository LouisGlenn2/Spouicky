<?php

	class Donnees extends CI_Model {
		public function __construct () {
			$this->load->database();
		}

		// ************************************
		// ******** Méthodes générales ********
		// ************************************

		// Retourne la relation demandée
		public function get (string $vue) : ?array {
			$this->db->select("*");
			$this->db->from($vue);

			return $this->db->get()->result_array();
		}

		private function supprimerNonAplhabétique (string $chaine) {
			return preg_replace('/[^a-z]/', "", $chaine);
		}

		private function supprimerDiacritiques (string $chaine) {
			return iconv('UTF-8', 'US-ASCII//TRANSLIT', $chaine);
		}

		// ************************************************
		// ******** Méthodes pour les utilisateurs ********
		// ************************************************

		private function genererLogin (string $nom, string $prenom, $type) : ?string {
			if ($type == TYPE_ETUDIANT) {
				// Supprimer les diacritiques du nom et du prénom
				$nom = $this->supprimerNonAplhabétique($this->supprimerDiacritiques(mb_strtolower($nom)));
				$prenom = $this->supprimerNonAplhabétique($this->supprimerDiacritiques(mb_strtolower($prenom)));

				// Les six premiers caractères du nom, le premier du prénom et un "i" constant
				return mb_substr($nom, 0, 6) . mb_substr($prenom, 0, 1) . "i";
			}

			else if ($type >= TYPE_TUTEUR) {
				// Simplement les huit premières lettres de son nom
				return mb_substr($this->supprimerDiacritiques(mb_strtolower($nom)), 0, 8);
			}

			else
				return null;
		}

		// Indique si cet utilisateur a un compte
		public function aCompte (string $login, string $mdp) : bool {
			$this->db->where([
				"login" => $login,
				"motdepasse" => $mdp
			]);
			$query = $this->db->get("_utilisateur");
			$count = $query->num_rows();
			return ($count == 1);
		}

		// Valide la connexion d’un utilisateur selon son pseudonyme et son mot de passe
		public function validerConnexion (string $pseudonyme, string $motDePasse) : ?array {
			$resultat = $this->db->query("SELECT * FROM tortue._utilisateur WHERE login = ? AND motdepasse = ?", [ $pseudonyme, $motDePasse ])->result_array();

			// Le premier résultat (et seul normalement) est l’utilisateur
			if (count($resultat) != 0) {
				$utilisateur = $resultat[0];
				$utilisateur["type"] = Donnees::typeUtilisateur($utilisateur["id"]);

				if ($utilisateur["type"] == TYPE_ETUDIANT)
					return $this->etudiant($utilisateur["id"]);

				else if ($utilisateur["type"] == TYPE_TUTEUR)
					return $this->tuteur($utilisateur["id"]);

				else if ($utilisateur["type"] == TYPE_SUPERTUTEUR)
					return $this->superTuteur($utilisateur["id"]);

				else
					return null;
			}

			else
				return null;
		}

		// Retourne l’utilisateur selon son identifiant et son rôle
		public function utilisateur (int $idUser, string $relation) : ?array {
			$resultat = $this->db->query("SELECT * FROM tortue." . $relation . " WHERE id = ?", [ $idUser ])->result_array();
			// Si le résultat contient au moins une ligne (c’est l’utilisateur), le retourne
			if (!empty($resultat))
				return array_merge($resultat[0], [
					"type" => $relation
				]);

			// Sinon, retourne null car il n’existe pas
			else{
				return [];
			}
		}

		public function typeUtilisateur ($idUser) {
			if (count($this->etudiant($idUser)) != 0)
				return TYPE_ETUDIANT;

			else if (count($this->superTuteur($idUser)) != 0)
				return TYPE_SUPERTUTEUR;

			else if (count($this->tuteur($idUser)) != 0)
				return TYPE_TUTEUR;

			else
				return TYPE_DECONNECTE;
		}

		// Modifie le mot de passe de cet utilisateur
		public function modifMdp ($idUser, $mdp) : bool {
			$resultat = $this->db->query("UPDATE tortue._utilisateur SET motdepasse = ? WHERE login = ?", [ $mdp, $idUser ]);

			return isset($resultat[0]);
		}

		// *********************************************
		// ******** Méthodes pour les étudiants ********
		// *********************************************

		// Retourne les étudiants
		public function etudiants () : array {
			return $this->db->get("etudiant")->result_array();
		}

		// Retourne cet étudiant
		public function etudiant (int $idUser) : ?array {
			return $this->utilisateur($idUser, "etudiant");
		}

		// Crée un étudiant avec des informations minimales
		public function ajouterEtu (string $nom, string $prenom, int $idannee, string $groupeClasse) {
			$mdp = "Lannion1";
			$login = $this->genererLogin($nom, $prenom, TYPE_ETUDIANT);
			$avatar = "newUser";
			$this->db->query("INSERT INTO tortue.etudiant (login, nom, prenom, motdepasse, idannee, groupeClasse, avatar) VALUES (?, ?, ?, ?, ?, ?, ?)", [$login, $nom, $prenom, $mdp, $idannee, $groupeClasse, $avatar]);
		}

		// Crée un étudiant avec des informations explicitement fournies
		public function ajouterEtudiant (string $login, string $nom, string $prenom, string $motDePasse, int $idAnnee, string $groupeClasse) : bool {
			$resultat = $this->db->query("INSERT INTO tortue.etudiant (login, nom, prenom, motDePasse, idAnnee, groupeClasse) VALUES (?, ?, ?, ?, ?, ?)", [ $login, $nom, $prenom, $motDePasse, $idAnnee, $groupeClasse ]);

			if ($resultat->result_query())
				return false;

			else
				return true;
		}

		// Supprime un étudiant
		public function supprimerEtudiant (int $id) : bool {
			$resultat = $this->db->query("DELETE FROM tortue.etudiant WHERE id = ?", [$id]);

			if ($resultat->result_query())
				return false;

			else
				return true;
		}

		// Supprimer un étudiant
		// @TODO supprimer, normalement remplacée par des triggers côté BDD
		public function suprEtu ($idEtu) {
			$this->db->query("DELETE FROM tortue.invitation WHERE idEtu = ?", [$idEtu]);
			$this->db->query("DELETE FROM tortue.tempgroupe WHERE idinvite = ? OR idcreateur = ?", [$idEtu, $idEtu]);
			$this->db->query("DELETE FROM tortue._appartient_grp WHERE idEtu = ?", [$idEtu]);
			$this->db->query("UPDATE tortue._sujet SET idcreateur = (SELECT id FROM tortue.super_tuteur) WHERE idcreateur = ?", [$idEtu]);
			$this->db->query("DELETE FROM tortue.etudiant WHERE id = ?", [$idEtu]);
		}

		// Indique si cet étudiant est membre d’un groupe
		public function estDansGroupe (int $idEtu) : bool {
			return !empty($this->db->query("SELECT * FROM tortue._appartient_grp WHERE idetu = ?", [ $idEtu ])->result_array());
		}

		// @TODO supprimer: c’est un double!
		public function inscritDansGroupe (int $idEtu) : bool {
			return !empty($this->db->query("SELECT * FROM tortue._appartient_grp WHERE idEtu = ?", [ $idEtu ])->result_array());
		}

		// Retourne l’identifiant du groupe de cet étudiant
		public function getNumGrp ($idEtu) {
			return $this->db->query("SELECT idgroupe FROM tortue._appartient_grp WHERE idetu = ?",[ $idEtu ])->result_array()[0] ?? null;
		}

		// @TODO supprimer: c’est un double!
		public function idGroupeEtudiant (int $idEtu) : ?array {
			return $this->db->query("SELECT idGroupe from tortue._appartient_grp WHERE idEtu = ?", [ $idEtu ])->result_array()[0] ?? null;
		}

		// Indique si cet étudiant est membre de ce groupe
		public function estInscritGroupe ($idEtu, $idGroupe) : bool {
			return !empty($this->db->query("SELECT * FROM tortue._appartient_grp WHERE idetu = ? AND idgroupe = ?", [ $idEtu, $idGroupe ])->result_array());
		}

		// Retournes les étudiants sans groupe
		public function etuSansGroupe () : array {
			return array_filter($this->etudiants(), function ($etu) {
				return !$this->Donnees->inscritDansGroupe($etu["id"]);
			});
		}

		// Retourne le groupe de cet étudiant
		public function obtenirGroupe (int $idEtu) : ?array {
			return $this->db->query("SELECT * FROM tortue.groupe INNER JOIN tortue._appartient_grp ON _appartient_grp.idgroupe = groupe.idgroupe AND idetu = ?", [ $idEtu ])->result_array()[0] ?? null;
		}

		// Retourne les membres du groupe de cet étudiant
		// @TODO recoder: utiliser les fonctions déjà existantes (getEtudiantsGroupe avec idGroupeEtudiants)
		public function groupeEtudiants (int $idEtu) : array {
			$idGroupe = $this->idGroupeEtudiant($idEtu);

			if ($idGroupe == null)
				return null;

			else
				return $this->db->query("SELECT idEtu FROM tortue._appartient_grp WHERE idGroupe = ?",[ $idGroupe ])->result_array();
		}

		// Retourne le nom du groupe de cet étudiant
		public function obtenirNomGroupe (int $idEtu) : ?string {
			return $this->obtenirGroupe($idEtu)["nomgroupe"];
		}

		// Désinscrit cet étudiant de son groupe
		public function quitterGroupe ($idEtu) {
			$idGroupe = $this->obtenirGroupe($idEtu)["idgroupe"];

			// Ne peut quitter s’il est dans un projet
			if (!$this->estInscritProjet($idGroupe)) {
				$this->db->query("DELETE FROM tortue._appartient_grp WHERE idetu = ?", [ $idEtu ]);

				// S'il ne reste personne dans le groupe, supprime le groupe
				if (count($this->groupe($idGroupe)) == 0) {

					//à gérer coté BDD plutot…:

					// supprimer les invitations envoyées par le groupe
					$this->db->query("DELETE FROM tortue._invitation WHERE idgroupe = ?", [ $idGroupe ]);
					// puis le groupe lui-même
					$this->db->query("DELETE FROM tortue._groupe WHERE idgroupe = ?", [ $idGroupe ]);
				}
			}
		}

		// Retourne l’avatar de cet étudiant
		public function avatar ($idEtu) : ?string {
			return ($this->db->query("SELECT avatar FROM tortue._etudiant WHERE idetu = ?", [ $idEtu ])->result_array())[0]["avatar"] ?? null;
		}

		// Change l’avatar de cet étudiant
		public function changerAvatar ($id, $avatar) : bool {
			$resultat = $this->db->query("UPDATE tortue._etudiant SET avatar = ? where idetu = ?", [ $avatar, $id ]);

			return isset($resultat[0]);
		}

		// *******************************************
		// ******** Méthodes pour les tuteurs ********
		// *******************************************

		// Retourne les tuteurs
		public function tuteurs () : array {
			return $this->db->get("tuteur")->result_array();
		}

		// Retourne ce tuteur
		public function tuteur (string $idTuteur) : ?array {
			return $this->utilisateur($idTuteur, "tuteur");
		}

		// Crée un tuteur ave dse informations minimales
		public function ajoutTuteur (string $nom, string $prenom, int $idAnnee) {
			$mdp = 'Lannion1';
			$login = $this->genererLogin($nom, $prenom, TYPE_TUTEUR);
			$this->db->query("INSERT INTO tortue.tuteur (login, nom, prenom, motdepasse, idannee) VALUES (?, ?, ?, ?, ?)", [ $login, $nom, $prenom, $mdp, $idAnnee ]);
		}

		// Crée un tuteur avec des informations explicites
		public function ajouterTuteur (string $login, string $nom, string $prenom, string $motDePasse, int $idAnnee) : bool {
			$resultat = $this->db->query("INSERT INTO tortue.tuteur (login, nom, prenom, motDePasse, idAnnee) VALUES (?, ?, ?, ?, ?, ?)", [ $login, $nom, $prenom, $motDePasse, $idAnnee ]);

			if ($resultat->result_query())
				return false;

			else
				return true;
		}

		// Supprime ce tuteur
		public function supprimerTuteur (int $id) : bool {
			$resultat = $this->db->query("DELETE FROM tortue.tuteur WHERE id = ?", [$id]);

			if ($resultat->result_query())
				return false;

			else
				return true;
		}

		// @TODO supprimer, remplacée par des triggers côté BDD
		public function suprTuteur ($idTuteur) {
			// vérifier que pas inscrit sur un projet
			$this->db->query("DELETE FROM tortue._tuteur_volontaire WHERE idtuteur = ?", [$idTuteur]);
			$this->db->query("UPDATE tortue._sujet SET idcreateur = (SELECT id FROM tortue.super_tuteur) WHERE idcreateur = ?", [$idTuteur]);
			$this->db->query("DELETE FROM tortue.tuteur WHERE id = ?", [ $idTuteur ]);
		}

		// *************************************************
		// ******** Méthodes pour les super‐tuteurs ********
		// *************************************************

		// Retourne le super‐tuteur
		public function superTuteur (string $idSTuteur) : ?array {
			return $this->utilisateur($idSTuteur, "super_tuteur");
		}

		// Indique si cet utilisateur est un super‐tuteur
		public function estSuperTuteur ($id) {
			return !empty($this->db->query("SELECT * FROM tortue.super_tuteur WHERE id = ?",[ $id ])->result_array());
		}

		// *******************************************
		// ******** Méthodes pour les groupes ********
		// *******************************************

		// Retourne les groupes
		public function groupes () : array {
			return $this->db->query("SELECT * FROM tortue.groupe")->result_array();
		}

		// Retourne ce groupe
		public function groupe (int $idGroupe) : ?array {
			return $this->db->query("SELECT * FROM tortue.groupe WHERE idGroupe = ?", [ $idGroupe ])->result_array()[0] ?? null;
		}

		// Crée un groupe
		public function creerGroupe (string $nomGroupe, $idCreateur) : int {
			$idGroupe = $this->db->query("INSERT INTO tortue.groupe (nomGroupe) VALUES (?) RETURNING idgroupe", [ $nomGroupe ], true)->result_array()[0]["idgroupe"];
			$this->db->query("INSERT INTO tortue._appartient_grp (idGroupe, idEtu) VALUES (?, ?)", [ $idGroupe, $idCreateur ]);
			return $idGroupe;
		}

		// Crée un groupe
		// @TODO cette fonction est‐elle vraiment utilisée ?
		public function ajouterGroupe ($nom) {
			$this->db->query("INSERT INTO tortue._groupe (nomgroupe) VALUES (?)", [ $nom ]);
		}

		// Retourne le nombre d’étudiants dans le groupe
		public function nombreEtuDansGroupe (int $idGroupe) : int {
			return count($this->getListeGroupe($idGroupe));
		}

		// Indique si ce groupe est complet (son nombre d’étudiants inscrits est égal à la limite)
		public function estGroupePlein (int $idGroupe) : bool {
			return $this->nombreEtuDansGroupe($idGroupe) == TAILLE_MAX_GROUPE;
		}

		// Retourne les groupes incomplets
		public function groupesIncomplets () : array {
			return array_filter($this->groupes(), function ($groupe) {
				return !$this->Donnees->estGroupePlein($groupe["idgroupe"]);
			});
		}

		// Ajoute cet étudiant à ce groupe
		public function rejoindreGroupe ($idEtu, $idGroupe) {
			$this->db->query("INSERT INTO tortue._appartient_grp (idEtu, idGroupe) VALUES(?, ?)", [ $idEtu, $idGroupe ]);
		}

		// Retourne les membres du groupe
		public function getEtudiantsGroupe ($idGroupe) : ?array {
			return $this->db->query("SELECT * FROM tortue._appartient_grp INNER JOIN tortue.etudiant ON idetu = id WHERE idgroupe = ?", [$idGroupe])->result_array() ?? null;
		}

		// @TODO supprimer: c’est un double!
		public function getListeGroupe ($idGroupe) : ?array {
			return $this->db->query("SELECT * FROM tortue._appartient_grp INNER JOIN tortue.etudiant ON id = idEtu WHERE idgroupe = ?",[ $idGroupe ])->result_array() ?? null;
		}

		// Supprimer ce groupe
		public function suprGroupe ($idGroupe) {
			$this->db->query("DELETE FROM tortue.invitation WHERE idGroupe = ?", [ $idGroupe ]);
			$this->db->query("DELETE FROM tortue._appartient_grp WHERE idGroupe = ?", [ $idGroupe ]);
			$this->db->query("DELETE FROM tortue._inscrit_sujet WHERE idGroupe = ?", [ $idGroupe ]);
			$this->db->query("DELETE FROM tortue.groupe WHERE idGroupe = ?", [ $idGroupe ]);
		}

		// Indique si ce groupe est inscrit sur un sujet
		// @TODO renommer “estInscritSurSujet”
		public function estInscritSujet ($idGroupe) {
			return !empty($this->db->query("SELECT * FROM tortue._inscrit_sujet WHERE idgroupe = ?", [ $idGroupe ])->result_array());
		}

		// Retourne les groupes n’étant inscrits sur aucun sujet
		public function groupesSansSujet () : array {
			return array_filter($this->groupes(), function ($groupe) {
				return !$this->Donnees->estInscritSujet($groupe["idgroupe"]);
			});
		}

		// Indique si ce groupe est inscrit à un projet
		public function estInscritProjet ($idGroupe) {
			return !empty($this->db->query("SELECT * FROM tortue._projet WHERE idgroupe = ?" ,[ $idGroupe ])->result_array());
		}

		// *******************************************************
		// ******** Méthodes pour les groupes temporaires ********
		// *******************************************************

		// Retourne le groupe temporaire de cet étudiant
		public function getTempGrp ($idEtu) {
			return $this->db->query("SELECT * FROM tortue.tempGroupe where idCreateur = ?", [ $idEtu ])->result_array();
		}

		// Ajoute dans le groupe temporaire de cet étudiant cet étudiant invité
		public function ajoutEtuTempGrp ($idCrea, $idInvit) {
			$this->db->query("INSERT INTO tortue.tempGroupe VALUES (?, ?)", [ $idCrea, $idInvit ]);
		}

		// Supprime du groupe temporaire de cet étudiant cet étudiant invité
		public function suprEtuTempGrp ($idCrea, $idInvit) {
			$this->db->query("DELETE FROM tortue.tempGroupe WHERE idCreateur = ? and idInvite = ?", [ $idCrea, $idInvit ]);
		}

		// Valide le groupe temporaire en invitations effectives
		public function inviterGroupeTemporaire ($idCreateur, string $nomGroupe) {
			$invitez = $this->getTempGrp($idCreateur);
			$idGroupe = $this->creerGroupe($nomGroupe, $idCreateur);

			// Faire une requête préparée pour optimiser
			foreach ($invitez as $invitation)
				$this->db->query("INSERT INTO tortue.invitation (idEtu, idGroupe) VALUES (?, ?)", [ $invitation["idinvite"], $idGroupe ]);

			$this->db->query("DELETE FROM tortue.tempGroupe WHERE idCreateur = ?", [ $idCreateur ]);
		}

		// ***********************************************
		// ******** Méthodes pour les invitations ********
		// ***********************************************

		// Retourne les invitations reçues par cet étudiant
		public function getListeInvit ($idEtu) : ?array {
			return $resultat = $this->db->query("SELECT * FROM tortue.invitation INNER JOIN tortue.groupe ON invitation.idgroupe = groupe.idgroupe WHERE idetu = ?", [ $idEtu ])->result_array() ?? null;
		}

		// Retourne les invitations envoyées par ce groupe
		public function getInvitGroupe ($idGroupe) : ?array {
			return $resultat = $this->db->query("SELECT * FROM tortue.invitation INNER JOIN tortue.etudiant ON id = idetu WHERE idgroupe = ?", [ $idGroupe ])->result_array() ?? null;
		}

		// Indique si cet étudiant a été invité par ce groupe
		public function estInviteGroupe ($idEtu, $idGroupe) : bool {
			return !empty($this->db->query("SELECT * FROM tortue.invitation WHERE idetu = ? AND idgroupe = ?", [ $idEtu, $idGroupe ])->result_array());
		}

		// Envoie une invitation de ce groupe à cet étudiant
		public function ajouterInvit (string $idEtu, string $idGroupe) : void {
			if ((count($this->getListeGroupe($idGroupe)) + count($this->getInvitGroupe($idGroupe))) >= TAILLE_MAX_GROUPE)
				echo "Déjà plein";

			else if ($this->estInscritGroupe($idEtu, $idGroupe))
				echo "Déjà ajouté";

			else if ($this->estInviteGroupe($idEtu, $idGroupe))
				echo "déjà inscrit";

			else
				$this->db->query("INSERT INTO tortue.invitation (idEtu, idGroupe) VALUES(?, ?)", [ $idEtu, $idGroupe ]);
		}

		// Accepte l’invitation de ce groupe à cet étudiant
		public function accepterInvit (int $idEtu, string $idGroupe) : void {
			$this->rejoindreGroupe($idEtu, $idGroupe);
			$this->supprimerInvit($idEtu, $idGroupe);
		}

		// Supprime l’invitation de ce groupe à cet étudiant
		public function supprimerInvit (int $idEtu, string $idGroupe) : void {
			$this->db->query("DELETE FROM tortue.invitation WHERE idEtu = ? AND idGroupe = ?", [ $idEtu, $idGroupe ]);
		}

		// ******************************************
		// ******** Méthodes pour les sujets ********
		// ******************************************

		// Retourne les sujets
		// @TODO renommer “sujets”
		public function toutSujet () : array {
			return $this->db->query("SELECT * FROM tortue.sujet")->result_array();
		}

		// Retourne les sujets validés
		public function toutSujetsValides () : array {
			return $this->db->query("SELECT * FROM tortue.sujet WHERE valide = true;")->result_array();
		}

		// Retourne les sujets non validés
		public function getListeSujetsNonValides () : array {
			return $this->db->query("SELECT * FROM tortue.sujet WHERE valide = false;")->result_array();
		}

		// Retourne ce sujet
		// @TODO renommer “sujet”
		public function infoSujet ($id) : ?array {
			return ($this->db->query("SELECT * FROM tortue.sujet WHERE idsujet = ?", [ $id ])->result_array())[0] ?? null;
		}

		// Crée un sujet
		public function ajouterSujet (string $titre, string $description, string $outils, int $idCreateur, int $idAnnee) : ?int {
			$idSujet = $this->db->query("INSERT INTO tortue._sujet (titre, description, outils, idcreateur, idannee, valide) VALUES (?, ?, ?, ?, ?, ?) RETURNING idSujet", [$titre, $description, $outils, $idCreateur, $idAnnee, false])->result_array()[0]["idsujet"];

			return $idSujet ?? null;
		}

		// Supprimer ce sujet
		public function supprimerSujet (int $id) : bool {
			$resultat = $this->db->query("DELETE FROM tortue.sujet WHERE idSujet = ?", [$id]);

			if ($resultat->result_query())
				return false;

			else
				return true;
		}

		// Valide le sujet
		public function validerSujet ($idSujet) {
			$this->db->query("UPDATE tortue._sujet SET valide = true WHERE idsujet = ?", [ $idSujet ]);
		}

		// Annuler le sujet
		public function annulerSujet ($idSujet) {
			$this->db->query("UPDATE tortue._sujet SET valide = false WHERE idsujet = ?", [ $idSujet ]);
		}

		// Modifie le descriptif d’un sujet
		public function modifierSujet ($idSujet, $titre, $description, $outil) {
			$this->db->query("UPDATE tortue._sujet SET titre = ?, description = ?, outils = ? WHERE idsujet = ?",[$titre, $description, $outil, $idSujet]);
		}

		// Retourne les sujets pour lesquels aucun groupe ne s’est proposé
		public function sujetsSansGroupe () : array {
			return array_filter($this->toutSujet(), function ($sujet) {
				return !$this->Donnees->estProjet($sujet["idsujet"]);
			});
		}

		// Indique si le sujet est associé à un projet
		public function estProjet ($idSujet) {
			return !empty($this->db->query("SELECT * FROM tortue.projet WHERE idsujet = ?",[$idSujet])->result_array());
		}

		// Retourne le sujet de cet étudiant
		public function monSujet ($idEtu) : ?array {
			return $this->db->query("SELECT idsujet FROM tortue.etudiant INNER JOIN tortue._appartient_grp ON id = idetu NATURAL JOIN tortue._inscrit_sujet WHERE idetu = ?", [ $idEtu ])->result_array()[0] ?? null;
		}

		// *************************************************************
		// ******** Méthodes pour les inscriptions sur un sujet ********
		// *************************************************************

		// Indique si ce groupe est inscrit sur ce sujet
		public function estInscritSurSujet ($idGroupe, $idSujet) {
			return (!empty($this->db->query("SELECT * FROM tortue._inscrit_sujet WHERE idgroupe = ? AND idsujet = ?", [ $idGroupe, $idSujet ])->result_array()));
		}

		// Retourne les groupes inscrits sur ce sujet
		// @TODO simplifier ? je vois mal comment cette méthode peut être aussi compliquée…
		public function getGroupesInscritSujet ($idSujet) {
			return $this->db->query("SELECT DISTINCT tortue.groupe.idgroupe, nomgroupe, idsujet FROM tortue.groupe INNER JOIN tortue._inscrit_sujet
ON tortue.groupe.idgroupe = tortue._inscrit_sujet.idgroupe INNER JOIN tortue._appartient_grp
ON tortue.groupe.idgroupe = tortue._appartient_grp.idgroupe INNER JOIN tortue.etudiant
ON tortue.etudiant.id = tortue._appartient_grp.idEtu WHERE idsujet = ?;", [$idSujet])->result_array();
		}

		// Inscrit ce groupe sur ce sujet
		public function inscrireSujet ($idGroupe, $idSujet) {
			$this->db->query("INSERT INTO tortue._inscrit_sujet VALUES(?, ?)", [ $idGroupe, $idSujet ]);
		}

		// Désinscrit ce groupe sur ce sujet
		public function desinscrireSujet ($idgroupe, $idsujet) {
			$this->db->query("DELETE FROM tortue._inscrit_sujet WHERE idgroupe = ? and idsujet = ?", [ $idgroupe, $idsujet ]);
		}

		// @TODO supprimer, c’est un double!
		public function supprimerGroupeSujet ($idSujet, $idGroupe) {
			$this->db->query("DELETE FROM tortue._inscrit_sujet WHERE idgroupe = ? AND idsujet = ?", [ $idGroupe, $idSujet ]);
		}

		// *************************************************************
		// ******** Méthodes pour les volontariats sur un sujet ********
		// *************************************************************

		// Indique si ce tuteur est volontaire sur ce sujet
		public function estVolontaireSujet ($idTuteur, $idSujet) {
			return !empty($this->db->query("SELECT * FROM tortue._tuteur_volontaire WHERE idtuteur = ? and idsujet = ?", [ $idTuteur, $idSujet ])->result_array());
		}

		// Retourne les tuteurs volontaire sur le sujet
		public function getTuteursInteresse ($sujet) {
			return $this->db->query("SELECT idtuteur, nom, prenom FROM tortue._tuteur_volontaire NATURAL JOIN tortue._sujet INNER JOIN tortue.tuteur ON id = idtuteur WHERE idsujet = ?", [$sujet])->result_array();
		}

		// Retourne les sujets sur lesquels le tuteur est volontaire
		public function getListeVolontariats ($idTuteur) {
			return $this->db->query("SELECT * FROM tortue._tuteur_volontaire INNER JOIN tortue.sujet ON tortue._tuteur_volontaire.idsujet = tortue.sujet.idsujet WHERE idtuteur = ?",[$idTuteur])->result_array();
		}

		// Inscrit ce tuteur comme volontaire sur ce sujet
		// @TODO renommer en “inscrireVolontaireSujet”
		public function devenirVolontaireSujet ($idTuteur, $idSujet) {
			$this->db->query("INSERT INTO tortue._tuteur_volontaire VALUES (?, ?)",[ $idTuteur, $idSujet ]);
		}

		// Désinscrit ce tuteur comme volontaire sur ce sujet
		// @TODO renommer en “desinscrireVolontaireSujet”
		public function annulerVolontaireSujet ($idTuteur, $idSujet) {
			$this->db->query("DELETE FROM tortue._tuteur_volontaire WHERE idtuteur = ? and idsujet = ?",[ $idTuteur, $idSujet ]);
		}

		// *******************************************
		// ******** Méthodes pour les projets ********
		// *******************************************

		// Retourne les projets
		public function projets () : array {
			return $this->db->get("projet")->result_array();
		}

		// Retourne ce projet
		public function projet (int $idProjet) : ?array {
			return ($this->db->query("SELECT * FROM tortue.projet WHERE idsujet = ?", [ $idProjet ])->result_array())[0] ?? null;
		}

		// Retourne les projets
		// @TODO renommer “projets”
		public function getProjet () {
			$res = $this->db->query("SELECT idsujet, idgroupe FROM tortue.projet")->result_array();

			if (empty($res))
				return [ [ null ] ]; // ???

			else
				return $res;
		}

		// Indique si ce sujet peut devenir un projet en fonction des groupes qui se proposent sur ce sujet et des tuteurs intéressés
		public function peutCreerProjet ($idSujet) {
			$groupesInscrits = $this->Donnees->getGroupesInscritSujet($idSujet);
			$somme = array_reduce($groupesInscrits, function ($somme, $groupe) {
				return $somme + count($this->getListeGroupe($groupe["idgroupe"]));
			}, 0);
			return !empty($this->Donnees->getTuteursInteresse($idSujet)) && !empty($groupesInscrits) && TAILLE_MIN_GROUPE <= $somme && $somme <= TAILLE_MAX_GROUPE;
		}

		// Crée un projet à partir des groupes existants
		// S’il y a plusieurs groupes positionnés dessus mais incomplets, les groupes sont fusionnés
		public function creerProjet (int $idSujet, int $idTuteur) : bool {
			$groupesInscrits = $this->getGroupesInscritSujet($idSujet);
			if ($this->peutCreerProjet($idSujet, $idTuteur)) {
				//Pour les groupes, fusionner les groupes et valider le groupe restant, le nom de groupe choisi sera … ?
				foreach ($groupesInscrits as $i => $groupe) {
					// On passe le premier groupe
					if ($i > 0) {
						foreach ($this->getListeGroupe($groupe["idgroupe"]) as $etudiant) {
							$this->quitterGroupe($etudiant["id"]);
							$this->rejoindreGroupe($etudiant["id"], $groupesInscrits[0]["idgroupe"]);
						}
						$this->supprimerGroupeSujet($idSujet, $idGroupe);
					}
				}

				$this->db->query("INSERT INTO tortue._projet (idsujet, idgroupe, idtuteur) VALUES (?, ?, ?)", [ $idSujet, $groupesInscrits[0]["idgroupe"], $idTuteur ]);
				// Supprime les groupes et tuteurs qui se proposent sur le sujet
				//à gérer coté BDD plutot…:
				$this->db->query("DELETE FROM tortue._inscrit_sujet WHERE idSujet = ?", [ $idSujet ]);
				$this->db->query("DELETE FROM tortue._tuteur_volontaire WHERE idSujet = ?", [ $idSujet ]);
				return true;
			}

			return false;
		}

		// Retourne le projet dont le sujet est
		public function getProjetSujetId ($idSujet) {
			return $this->db->query("SELECT * FROM tortue.projet WHERE idsujet = ?",[$idSujet])->result_array();
		}

		// Retjourne le projet de l’utilisateur connecté à partir de l’identifiant de son groupe
		public function monProjet ($idgroupe) : ?array {
			return $this->db->query("SELECT * FROM tortue.projet WHERE idgroupe = ?",[ $idgroupe ])->result_array()[0] ?? null;
		}

		// Supprime un projet
		public function supprimerProjet ($idSujet) {
			$this->db->query("DELETE FROM tortue._projet WHERE idsujet = ?",[$idSujet]);
		}

		// **********************************************
		// ******** Méthodes pour les recherches ********
		// **********************************************

		// Retourne les sujets conrrespondant à la recherche
		public function getRechSujet ($contenu) {
			return $this->db->query("SELECT idsujet, tortue._utilisateur.nom, tortue._utilisateur.prenom, titre FROM tortue.sujet INNER JOIN tortue._utilisateur ON idcreateur = id WHERE lower(titre) LIKE lower('%" . $contenu . "%')")->result_array();
		}

		// Retourne les sujets validés conrrespondant à la recherche
		public function getRechSujetValide ($contenu) {
			return $this->db->query("SELECT idsujet, tortue._utilisateur.nom, tortue._utilisateur.prenom, titre FROM tortue.sujet INNER JOIN tortue._utilisateur ON idcreateur = id WHERE lower(titre) LIKE lower('%" . $contenu . "%') and valide = true")->result_array();
		}

		// Retourne les groupes conrrespondant à la recherche
		public function getRechGroupe (string $nom) : array {
			return $this->db->query("SELECT * FROM tortue.groupe WHERE lower(nomgroupe) LIKE lower('%" . $nom . "%')")->result_array();
		}

		// Retourne les étudiants correspondant à la recherche
		public function getRechEtu ($nom) {
			return $this->db->query("SELECT * FROM tortue.etudiant WHERE lower(nom) LIKE lower('%" . $nom . "%') OR lower(prenom) LIKE lower('%" . $nom . "%')")->result_array();
		}

		// Retourne les tuteurs correspondant à la recherche
		public function getRechTuteurs (string $nom) : array {
			return $this->db->query("SELECT * FROM tortue.tuteur WHERE lower(nom) LIKE lower('%" . $nom . "%') OR lower(prenom) LIKE lower('%" . $nom . "%')")->result_array();
		}

	}

?>