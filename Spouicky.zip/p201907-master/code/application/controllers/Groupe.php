<?php

	require "General.php";

	class Groupe extends General {
		public function __construct () {
			parent::__construct();
		}

		public function index () {
			if ($this->estConnecte())
				redirect("/tortue/monCompte");

			else
				redirect("/tortue/connexion");
		}

		 public function creerGroupe () {
			$this->load->helper("form");
			$this->load->library("form_validation");

			// Récupère la recherche ou met une chaîne vide par défaut
			$rech = $this->security->xss_clean($this->input->post("rech")) ?? "";
			$etudiantPlus = $this->security->xss_clean($this->input->post("ajoutEtu")) ?? null;
			$etudiantMoins = $this->security->xss_clean($this->input->post("suprEtu")) ?? null;
			$validation = $this->security->xss_clean($this->input->post("valider")) ?? null;

			// Si la chaine n'est pas vide, fait la recherche
			// @TODO : prendre aussi en compte qu'un étudiant de la liste temporaire ne doit être affiché dans les résultats de recherche
				// -> utiliser array_diff
			if ($rech != "")
				$res = $this->Donnees->getRechEtu($rech) ?? [];

			// Sinon, les résultats sont un tableau vide 
			else
				$res = [];

			// Et ajoute un indicateur de résultat
			$boolResultat = !empty($res);

			if ($etudiantPlus != null) {
				//Pour ne pas s'ajouter soi-même
				if ($etudiantPlus == $this->id())
					echo "Inutile de vous ajouter vous-même !";

				else if (count($this->Donnees->getTempGrp($this->id())) >= (TAILLE_MAX_GROUPE - 1))
					echo "Vous ne pouvez pas ajouter plus d'étudiants dans ce groupe.";

				else
					$this->Donnees->ajoutEtuTempGrp($this->id(), $etudiantPlus);
			}

			if ($etudiantMoins != null) {
				// alors supprimer l'etudiant à la liste temporaire
				// prendre aussi en compte qu'un étudiant de la liste temporaire ne peut être affiché dans la liste des résultats de recherche...
				$this->Donnees->suprEtuTempGrp($this->id(), $etudiantMoins);
			}

			if ($validation != null) {
				$nom = html_escape($this->input->post("nomGroupe"));
				if (count($this->Donnees->getTempGrp($this->id())) == 0) {
					echo 'Invitez au moins un gens sale schtroumpf valétudinaire !';
				}
				else if (strlen($nom) < 3 || strlen($nom) > 16) {
					echo 'Donner un nom valide !';
				}
				else {
					$this->Donnees->inviterGroupeTemporaire($this->id(), $nom);
					redirect("/tortue/monCompte");
				}
			}

			$this->load->view('creerGroupe', [
				"idUser" => $this->id(),
				"resultats" => $res,
				"boolResultat" => $boolResultat,
				"recherche" => $rech,
				"listeInvit" => $this->Donnees->getListeInvit($this->id()),
				"groupeTempo" => $this->Donnees->getTempGrp($this->id()),
			]);
		}

		public function inviter () {
			$idEtu = $this->input->post("ajoutEtu");
			$idGroupe = $this->Donnees->idGroupeEtudiant($this->id())["idgroupe"];

			$this->Donnees->ajouterInvit($idEtu, $idGroupe);
			redirect("/Tortue/monCompte");
		}

		public function affecterEtu () {
			$idEtu = $this->input->post("etu");
			$idGroupe = $this->input->post("groupe");

			// On vérifie par sécurité (injection de fausses valeurs possibles)
			if (!$this->Donnees->estDansGroupe($idEtu) && !$this->Donnees->estGroupePlein($idGroupe))
				$this->Donnees->rejoindreGroupe($idEtu, $idGroupe);

			redirect("/Tortue/gereEtudiants");
		}

		public function accepterInvit () {
			$idEtu = $this->id();
			$idGroupe = $this->input->post("idGroupe");

			if (!$this->Donnees->estDansGroupe($idEtu))
				$this->Donnees->accepterInvit($idEtu, $idGroupe);

			redirect("/Tortue/monCompte");
		}

		public function refuserInvit () : void {
			$idEtu = $this->id();
			$idGroupe = $this->input->post("idGroupe");
			$this->Donnees->supprimerInvit($idEtu, $idGroupe);
			redirect("/Tortue/monCompte");
		}

		public function supprimerInvit () {
			$idEtu = $this->input->post("supprInvitEtu");

			$idGroupe = $this->Donnees->idGroupeEtudiant($this->id())["idgroupe"];

			$this->Donnees->supprimerInvit($idEtu, $idGroupe);

			redirect("/Tortue/monCompte");
		}

		public function quitterGroupe () {
			if ($this->Donnees->inscritDansGroupe($this->id())) {
				$this->Donnees->quitterGroupe($this->id());

				redirect("tortue/monCompte");
			}

			else
				redirect("/tortue");
		}
	}

?>