<?php

	abstract class General extends CI_Controller {
		public function __construct () {
			parent::__construct();

			$this->load->library("session");
			$this->load->helper("url");
			$this->load->model("Donnees");
			$this->load->vars([ "user" => $this->userConnecte() ]);
		}

		protected function userConnecte () : ?array {
			return $this->session->userdata("user");
		}

		protected function id () : int {
			return $this->session->userdata("user")["id"];
		}

		protected function login () : int {
			return $this->session->userdata("user")["login"];
		}

		protected function role () : int {
			return $this->Donnees->typeUtilisateur($this->id());
		}

		protected function estConnecte () : bool {
			$user = $this->userConnecte();
			return $user !== null && !empty($user);
		}

		protected function connecterUser (string $login, string $motDePasse) {
			if (!$this->estConnecte()) {
				$utilisateur = $this->Donnees->validerConnexion($login, $motDePasse);

				if ($utilisateur)
					$this->session->set_userdata("user", $utilisateur);
			}
		}
	}

?>