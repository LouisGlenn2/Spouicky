<?php

	require "General.php";

	class Sujet extends General {
		public function __construct () {
			parent::__construct();
		}

		public function index () {
			if ($this->estConnecte())
				redirect("/tortue/monCompte");

			else
				redirect("/tortue/connexion");
		}

		public function proposerSujet () : void {
			$this->load->helper("form");
			$this->load->library("form_validation");
			$data["title"] = "proposerSujet";

			$this->form_validation->set_rules("intitule" , "titre" , "required");
			$this->form_validation->set_rules("description" , "description" , "required");
			$this->form_validation->set_rules("outil" , "outil" , "required");
			$this->load->view("proposerSujet", [
				"modif" => null
			]);

			if (! $this->form_validation->run())
				$data["content"] = "ProposerSujet";

			else {
				$titre = $this->security->xss_clean($this->input->post("intitule"));
				$description = $this->security->xss_clean($this->input->post("description"));
				$outil = $this->security->xss_clean($this->input->post("outil"));
				$idCreateur = $this->id();
				$idannee = $this->session->userdata("user")["idannee"];

				if ($idCreateur == null)
					echo "error";

				else {
					$idSujet = $this->Donnees->ajouterSujet($titre, $description, $outil, $idCreateur, $idannee);

					if ($this->Donnees->typeUtilisateur($this->id()) == TYPE_ETUDIANT) {
						$idGroupe = $this->Donnees->obtenirGroupe($idCreateur)["idgroupe"];

						$this->Donnees->inscrireSujet($idGroupe, $idSujet);
					}
				}

				redirect("/tortue/accueilUser");
			}
		}

		public function voirSujet (string $idSujet) {
			$this->load->helper("form");
			$this->load->library("form_validation");

			$this->load->view("descripSujet", [
				"sujetSelect" => $this->Donnees->infoSujet($idSujet),
				"tuteurs" => $this->Donnees->getTuteursInteresse($idSujet),
				"groupesSujet" => $this->Donnees->getGroupesInscritSujet($idSujet)
			]);
		}

		public function inscrireSujet () {
			if ($this->Donnees->estDansGroupe($this->id())) {
				$groupe = $this->Donnees->obtenirGroupe($this->id());
				$idSujet = $this->input->post("idSujet");

				if (!$this->Donnees->estInscritSujet($groupe["idgroupe"])) {
					$this->Donnees->inscrireSujet($groupe["idgroupe"], $idSujet);
					redirect("sujet/voirSujet/$idSujet");
				}
				else
					redirect("/tortue/accueilUser");
			}
			else
				redirect("/tortue/accueilUser");
		}

		public function desinscrireSujet () {
			$groupe = $this->Donnees->obtenirGroupe($this->id());
			$idSujet = $this->input->post("idSujet");

			if ($this->Donnees->estInscritSurSujet($groupe["idgroupe"], $idSujet)) {
				$this->Donnees->desinscrireSujet($groupe["idgroupe"], $idSujet);
				redirect("sujet/voirSujet/$idSujet");
			}

			redirect("/tortue/accueilUser");
		}

		public function affecterGroupe () {
			$idGroupe = $this->input->post("groupe");
			$idSujet = $this->input->post("sujet");

			// On vérifie par sécurité (injection de fausses valeurs possibles)
			if (!$this->Donnees->estInscritSujet($idGroupe) && !$this->Donnees->estProjet($idSujet))
				$this->Donnees->inscrireSujet($idGroupe, $idSujet);

			redirect("/Tortue/gereGroupes");
		}

		public function devenirVolontaireSujet () {
			$idSujet = $this->input->post("idSujet");
			if (!$this->Donnees->estVolontaireSujet($this->id(), $idSujet)) {
				$this->Donnees->devenirVolontaireSujet($this->id(), $idSujet);
				redirect("sujet/voirSujet/$idSujet");
			}
			else
				redirect("/tortue/accueilUser");
		}

		public function annulerVolontaireSujet () {
			$idSujet = $this->input->post("idSujet");

			if ($this->Donnees->estVolontaireSujet($this->id(), $idSujet))
				$this->Donnees->annulerVolontaireSujet($this->id(), $idSujet);

			redirect("sujet/voirSujet/$idSujet");
		}

		public function supprimerTuteurSujet () {
			$idSujet = $this->input->post("idSujet");
			$idTuteur = $this->input->post("idTuteur");

			if ($this->Donnees->estVolontaireSujet($this->id(), $idSujet))
				$this->Donnees->annulerVolontaireSujet($idTuteur, $idSujet);

			redirect("sujet/voirSujet/$idSujet");
		}

		public function validerSujet () {
			$idSujet = $this->input->post("idSujet");
			$this->Donnees->validerSujet($idSujet);
			redirect("sujet/voirSujet/$idSujet");
		}

		public function supprimerSujet () {
			$idSujet = $this->input->post("idSujet");
			$this->Donnees->supprimerSujet($idSujet);
			redirect("sujet/voirSujet/$idSujet");
		}

		public function annulerValidation () {
			$idSujet = $this->input->post("idSujet");
			$this->Donnees->annulerSujet($idSujet);
			
			$groupes = $this->Donnees->getGroupesInscritSujet($idSujet);

			foreach ($groupes as $grp)
				$this->Donnees->desinscrireSujet($grp["idgroupe"], $idSujet);
			
			$tuteurs = $this->Donnees->getTuteursInteresse($idSujet);

			foreach ($tuteurs as $tut)
				$this->Donnees->annulerVolontaireSujet($tut["idtuteur"], $idSujet);

			$this->voirSujet($idSujet);
		}

		public function supprimerGroupeSujet () : void {
			$idSujet = $this->input->post("idSujet") ?? -1; // rediriger si non existant, sécurité………
			$this->Donnees->supprimerGroupeSujet($idSujet, $this->input->post("idGroupe"));
			redirect("sujet/voirSujet/$idSujet");
		}

		public function creerProjet () {
			$idSujet = $this->input->post("idSujet");
			$idTuteur = $this->input->post("tuteur");
			$retour = $this->Donnees->creerProjet($idSujet, $idTuteur);
			redirect("sujet/voirSujet/$idSujet");
		}

		public function modifierSujet(int $idSujet) {
			$this->load->helper("form");
			$sujet = $this->Donnees->infoSujet($idSujet);
			$this->load->view("proposerSujet", [
					"sujet" => $sujet,
				]);
		}

		public function validerModifSujet () {
			$this->load->helper("form");
			$this->load->library("form_validation");
			$this->form_validation->set_rules("intitule" , "titre" , "required");
			$this->form_validation->set_rules("description" , "description" , "required");
			$this->form_validation->set_rules("outil" , "outil" , "required");
			$idSujet = $this->input->post("idSujet");

			if (!$this->form_validation->run())
				redirect("/Sujet/modifierSujet/" . $idSujet);

			else {
				$titre = $this->security->xss_clean($this->input->post("intitule"));
				$description = $this->security->xss_clean($this->input->post("description"));
				$outil = $this->security->xss_clean($this->input->post("outil"));
				$idCreateur = $this->id();
				$idannee = $this->session->userdata("user")["idannee"];

				if ($idCreateur != null)
					$this->Donnees->modifierSujet($idSujet, $titre, $description, $outil);

				redirect("/tortue/accueilUser");
			}
		}

		public function annulerProjet () {
			$idSujet = $this->input->post("idSujet");
			$this->Donnees->supprimerProjet($idSujet);
			redirect("sujet/voirSujet/$idSujet");
		}
	}

?>