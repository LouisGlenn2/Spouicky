<?php

	require "General.php";

	class Tortue extends General {
		public function __construct () {
			parent::__construct();
		}

		public function index () {
			if ($this->estConnecte())
				redirect("/tortue/monCompte");

			else
				redirect("/tortue/connexion");
		}

		public function connexion () {
			if ($this->estConnecte())
				redirect("/tortue/accueilUser");

			$this->load->helper("form");
			$this->load->library("form_validation");

			$this->form_validation->set_rules("login", "LOGIN", "required");
			$this->form_validation->set_rules("motdepasse", "motdepasse", "required");	

			if ($this->form_validation->run()) {
				$login = $this->security->xss_clean($this->input->post("login"));
				$motDePasse = $this->security->xss_clean($this->input->post("motdepasse"));
				// @TODO faire du hashage de mot de passe par sécurité
				// Tiger est faible, voir plutôt SHA
				//$motdepasse= hash("tiger192",$motdepasse); /* Récupère les valeurs */

				if ($this->Donnees->aCompte($login, $motDePasse)) {
					$this->connecterUser($login, $motDePasse);

					redirect("tortue/accueilUser");
				}

				// S’il y a une erreur lors de la tentative de connexion
				else
					echo "Authentication Failed";
			}

			$this->load->view("connexion");
		}

		public function monCompte ($bool = false) : void {
			$compte = $this->userConnecte();
			$type = $this->Donnees->typeUtilisateur($this->id());

			if ($this->estConnecte() == null)
				redirect("/tortue/connexion");

			$this->load->helper("form");

			$rech = $this->security->xss_clean($this->input->post("rech") ?? "");

			// Si la chaine n’est pas vide, fait la recherche
			if ($rech != "")
				$res = $this->Donnees->getRechEtu($rech) ?? [];

			// Sinon, les résultats sont un tableau vide 
			else
				$res = [];

			$listeInvitations = $this->Donnees->getListeInvit($compte["id"]);
			$estInvite = $listeInvitations !== null;
			$invitations = [];

			if ($listeInvitations !== null) {
				foreach ($listeInvitations as $invitation) {
					$invitations[] = [
						"idGroupe" => $invitation["idgroupe"],
						"nomGroupe" => $this->Donnees->groupe($invitation["idgroupe"])["nomgroupe"],
						"etudiants" => $this->Donnees->getListeGroupe($invitation["idgroupe"]),
					];
				}
			}

			$this->load->view("monCompte", [
				"type" => $this->Donnees->typeUtilisateur($compte["id"]),
				"compte" => $compte,
				"formmdp" => $bool,
				"avatar" => $this->Donnees->avatar($compte["id"]),
			]);

			if ($this->Donnees->inscritDansGroupe($this->id())) {
				$monGroupe = $this->Donnees->obtenirGroupe($this->id());
				$this->load->view("compteEtuAvecGroupe", [
					"type" => $this->Donnees->typeUtilisateur($compte["id"]),
					"compte" => $compte,
					"resultats" => $res,
					"estInvite" => $estInvite,
					"invitations" => $invitations,
					"monGroupe" => array_merge($monGroupe, [
						"inscrits" => $this->Donnees->getListeGroupe($monGroupe["idgroupe"]),
						"invites" => $this->Donnees->getInvitGroupe($monGroupe["idgroupe"]),
					]),
				]);
			}

			else if ($type != TYPE_TUTEUR && $type != TYPE_SUPERTUTEUR)
				$this->load->view("compteEtuSansGroupe", [
					"type" => $this->Donnees->typeUtilisateur($compte["id"]),
					"compte" => $compte,
					"estInvite" => $estInvite,
					"invitations" => $invitations,
				]);
		}

		public function modifierMotDePasse () {
			$this->monCompte(); // ??

			$nouveauMDP = $this->security->xss_clean($this->input->post("motdepasse"));

			// TODO utiliser plutôt les fonctions de CodeIgniter pour les vérifications de sécurité
			if (strlen($nouveauMDP) >= 5) {
				$this->Donnees->modifMdp($this->login(), $nouveauMDP);
				// TODO utiliser des annotations, plus fiables et esthétiques
				echo "Mot de passe modifié !";
			}

			else
				echo "Votre mot de passe doit être de 5 caractères ou plus !";
		}

		 public function deconnexion () {
			$this->session->sess_destroy();

			redirect("Tortue/connexion");
		}

		public function loadModifMdp () {
			$this->load->helper("form");
			$this->load->library("form_validation");

			$this->load->view("modifMdp");
		}

		// @TODO supprimer: inutilisée
		public function rechEtu () {
			$rech = $this->security->xss_clean($this->input->post("rech") ?? "");

			$res = $this->Donnees->getRechEtu($rech);
		}

		public function gereEtudiants () {
			if ($this->role() <= TYPE_TUTEUR)
				redirect("/tortue");

			$this->load->helper("form");

			$rec = $this->security->xss_clean($this->input->post("rech") ?? "");

			$recEtu = $this->Donnees->getRechEtu($rec);

			$listeEtu = $this->Donnees->etudiants();

			$this->load->view('gereEtudiants', ['etu' => $listeEtu, 'recEtu' => $recEtu, "rec" => $rec]);
		}

		public function suprEtu () {
			$etu = $this->input->post("idetu");

			$this->Donnees->suprEtu($etu);

			redirect("Tortue/gereEtudiants");
		}

		public function ajouterEtu () {
			if ($this->role() <= TYPE_TUTEUR)
				redirect("/tortue");

			$nom = $this->security->xss_clean($this->input->post("nom"));
			$prenom = $this->security->xss_clean($this->input->post("prenom"));
			$annee = $this->security->xss_clean($this->input->post("annee"));
			$groupeClasse = $this->security->xss_clean($this->input->post("groupeClasse"));

			$this->Donnees->ajouterEtu($nom, $prenom, $annee, $groupeClasse);

			redirect("Tortue/gereEtudiants");
		}

		// @TODO supprimer: inutilisée
		public function rechGroupe () {
			$rech = $this->security->xss_clean($this->input->post("rech") ?? "");

			$res = $this->Donnees->getRechGroupe($rech);
		}

		public function gereGroupes () {
			if ($this->role() <= TYPE_TUTEUR)
				redirect("/tortue");

			$this->load->helper("form");

			$rec = $this->security->xss_clean($this->input->post("rech") ?? "");

			$recGroupes = $this->Donnees->getRechGroupe($rec);

			$listeGroupes = $this->Donnees->groupes();

			$this->load->view('gereGroupes', [ 'groupes' => $listeGroupes, 'recGroupes' => $recGroupes, "rec" => $rec ]);
		}

		public function ajouterGroupe () {
			if ($this->role() <= TYPE_TUTEUR)
				redirect("/tortue");

			$nom = $this->security->xss_clean($this->input->post("nom"));

			$this->Donnees->ajouterGroupe($nom);

			redirect("Tortue/gereGroupes");
		}

		public function suprGroupe () {
			if ($this->role() <= TYPE_TUTEUR)
				redirect("/tortue");

			$groupe = $this->input->post("idgroupe");

			$this->Donnees->suprGroupe($groupe);

			redirect("Tortue/gereGroupes");
		}

		// @TODO supprimer: inutilisée
		public function rechTuteur () {
			$rech = $this->security->xss_clean($this->input->post("rech") ?? "");

			$res = $this->Donnees->getRechTuteurs($rech);
		}

		public function gereTuteurs () {
			if ($this->role() <= TYPE_TUTEUR)
				redirect("/tortue");

			$this->load->helper("form");

			$rec = $this->security->xss_clean($this->input->post("rech") ?? "");

			$recTuteurs = $this->Donnees->getRechTuteurs($rec);

			$listeTuteurs = $this->Donnees->tuteurs();

			$this->load->view('gereTuteurs', ['tuteurs' => $listeTuteurs, 'recTuteurs' => $recTuteurs, "rec" => $rec]);
		}

		public function ajouterTuteur () {
			if ($this->role() <= TYPE_TUTEUR)
				redirect("/tortue");

			$nom = $this->security->xss_clean($this->input->post("nom"));
			$prenom = $this->security->xss_clean($this->input->post("prenom"));
			$annee = $this->security->xss_clean($this->input->post("annee"));

			$this->Donnees->ajoutTuteur($nom, $prenom, $annee);

			redirect("Tortue/gereTuteurs");
		}

		public function suprTuteur () {
			if ($this->role() <= TYPE_TUTEUR)
				redirect("/tortue");

			$tuteur = $this->input->post("idtuteur");

			$this->Donnees->suprTuteur($tuteur);

			redirect("Tortue/gereTuteurs");
		}
        
		public function accueilUser () {
			$this->load->helper("form");

			$idSujet = $this->Donnees->monSujet($this->id());

			$idgroupe = $this->Donnees->getNumGrp($this->id());

			$rech = $this->security->xss_clean($this->input->post("rechercher")) ?? "";

			if ($rech != "") {
				if ($this->role() == TYPE_SUPERTUTEUR)
					$res = $this->Donnees->getRechSujet($rech) ?? [];

				else
					$res = $this->Donnees->getRechSujetValide($rech) ?? [];
			}

			// Sinon, les résultats sont un tableau vide 
			else
				$res = [];

			// Et ajoute un indicateur de résultat
			$boolResultat = !empty($res);

			if ($this->role() == TYPE_ETUDIANT) {
				$this->load->view("accueilUser", [
					"compte" => $this->userConnecte(),
					"sujet" => $this->Donnees->toutSujet(),
					"numProjet"=> $this->Donnees->getProjet(),
					"idgroupe"=> $idSujet == null ? null : $this->Donnees->getNumGrp($this->id()),
					"infoMonSujet" => $idSujet == null ? null : $this->Donnees->infoSujet($idSujet),
					"resultats" => $res,
					"boolResultat" => $boolResultat,
					"recherche" => $rech,
					"tousSujets" => $this->Donnees->toutSujetsValides(),
					"infoMonProjet" => $idgroupe == null ? null : $this->Donnees->monProjet($idgroupe)
				]);
			}

			else if ($this->role() == TYPE_TUTEUR)
				$this->load->view("accueilTuteur.php", [
					"compte" => $this->userConnecte(),
					"resultats" => $res,
					"numProjet"=> $this->Donnees->getProjet(),
					"tousSujets" => $this->Donnees->toutSujetsValides(),
				]);

			else if ($this->role() == TYPE_SUPERTUTEUR)
				$this->load->view("accueilSuperTuteur.php", [
					"compte" => $this->userConnecte(),
					"resultats" => $res,
					"numProjet"=> $this->Donnees->getProjet(),
					"tousSujets" => $this->Donnees->toutSujet(),
				]);

			else
				redirect("/tortue/connexion");
		}

		public function changerAvatar () {
			$this->monCompte(); // ??

			$nouveauAvatar = $this->security->xss_clean($this->input->post("avatar"));

			$this->Donnees->changerAvatar($this->id(), $nouveauAvatar);
            //$this->actualiserUser();

            redirect("/tortue/monCompte");
		}

	}
    
?>