# un compte pour l'espace Web à l'IUT et la BDD
user : p201907
mdp : Lannion1 (à changer sous Windows)

Ce compte sert pour la BDD (PostgreSQL) également.