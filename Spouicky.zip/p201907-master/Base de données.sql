
CREATE SCHEMA tortue;

CREATE TABLE tortue._utilisateur (
	id Serial NOT NULL,
	login VARCHAR(8) NOT NULL,
	nom VARCHAR(20) NOT NULL,
	prenom VARCHAR(20) NOT NULL,
	motDePasse VARCHAR(64) NOT NULL,
	idAnnee Integer NOT NULL,
	CONSTRAINT pk_util PRIMARY KEY (id)
);

CREATE TABLE tortue._etudiant (
	idEtu Integer NOT NULL,
	groupeClasse VARCHAR(2) NOT NULL,
	avatar VARCHAR(16) NOT NULL,
	CONSTRAINT pk_etudiant PRIMARY KEY (idEtu),
	CONSTRAINT fk_etuUtil FOREIGN KEY (idEtu) REFERENCES tortue._utilisateur (id)
);

CREATE TABLE tortue._tuteur (
	idTuteur Integer NOT NULL,
	CONSTRAINT pk_tuteur PRIMARY KEY (idTuteur),
	CONSTRAINT fk_tuteurUtil FOREIGN KEY (idTuteur) REFERENCES tortue._utilisateur (id)
);

CREATE TABLE tortue._super_tuteur (
	idStuteur Integer NOT NULL,
	CONSTRAINT pk_super_tuteur PRIMARY KEY (idStuteur),
	CONSTRAINT fk_tuteur_tuteur FOREIGN KEY (idStuteur) REFERENCES tortue._tuteur (idTuteur)
);

CREATE VIEW tortue.etudiant AS (
	Select id, login, nom, prenom, motDePasse, idAnnee, groupeClasse, avatar FROM tortue._utilisateur INNER JOIN tortue._etudiant ON id = idEtu
);

CREATE VIEW tortue.tuteur AS (
	Select id, login, nom, prenom, motDePasse, idAnnee FROM tortue._utilisateur INNER JOIN tortue._tuteur ON id = idTuteur
);

CREATE VIEW tortue.super_tuteur AS (
	Select id, login, nom, prenom, motDePasse, idAnnee FROM tortue._utilisateur INNER JOIN tortue._super_tuteur ON id = idStuteur
);

CREATE TABLE tortue._groupe (
	idGroupe Serial NOT NULL,
	nomGroupe VARCHAR(30) NOT NULL,
	CONSTRAINT pk_grp PRIMARY KEY (idGroupe)
);

CREATE VIEW tortue.groupe AS (
	SELECT * FROM tortue._groupe
);

CREATE TABLE tortue._appartient_grp (
	idGroupe Integer NOT NULL,
	idEtu Integer NOT NULL,
	CONSTRAINT pk_appartient PRIMARY KEY (idEtu),
	CONSTRAINT fk_appartientGroupe FOREIGN KEY (idGroupe) REFERENCES tortue._groupe (idGroupe),
	CONSTRAINT fk_appartientEtu FOREIGN KEY (idEtu) REFERENCES tortue._etudiant (idEtu)
);

CREATE TABLE tortue._sujet (
	idSujet Serial NOT NULL,
	titre VARCHAR(30) NOT NULL,
	description VARCHAR(2500) NOT NULL,
	outils VARCHAR(250) NOT NULL,
	idCreateur Integer NOT NULL,
	idAnnee Integer NOT NULL,
	CONSTRAINT pk_sujet PRIMARY KEY (idSujet)
);
-- vérifier avec le prof que le schéma est correct (contraintes d'un étudiant qui ne peut créer plus de deux sujets)

CREATE TABLE tortue._inscrit_sujet (
	idGroupe Integer NOT NULL,
	idSujet Integer NOT NULL,
	CONSTRAINT pk_inscrit PRIMARY KEY (idGroupe, idSujet),
	CONSTRAINT fk_inscritGroupe FOREIGN KEY (idGroupe) REFERENCES tortue._groupe (idGroupe),
	CONSTRAINT fk_inscritSujet FOREIGN KEY (idSujet) REFERENCES tortue._sujet (idSujet)
);

CREATE TABLE tortue._tuteur_volontaire (
	idTuteur Integer NOT NULL,
	idSujet Integer NOT NULL,
	CONSTRAINT pk_volontaire PRIMARY KEY(idTuteur, idSujet),
	CONSTRAINT fk_volontaireTuteur FOREIGN KEY (idTuteur) REFERENCES tortue._tuteur (idTuteur),
	CONSTRAINT fk_volontaireSujet FOREIGN KEY (idSujet) REFERENCES tortue._sujet (idSujet)
);

CREATE TABLE tortue._projet (
	idProjet Serial NOT NULL,
	idSujet Integer NOT NULL UNIQUE,
	idGroupe Integer NOT NULL UNIQUE,
	idTuteur Integer NOT NULL,
	CONSTRAINT pk_projet PRIMARY KEY (idProjet),
	CONSTRAINT fk_projetSujet FOREIGN KEY (idSujet) REFERENCES tortue._sujet (idSujet),
	CONSTRAINT fk_projetGroupe FOREIGN KEY (idGroupe) REFERENCES tortue._groupe (idGroupe),
	CONSTRAINT fk_projetTuteur FOREIGN KEY (idTuteur) REFERENCES tortue._tuteur (idTuteur)
);

CREATE OR REPLACE VIEW tortue.sujet AS (
	SELECT idsujet, titre, description, outils, idcreateur, _sujet.idannee, valide, login, nom, prenom, groupeclasse FROM tortue._sujet INNER JOIN tortue.etudiant ON idcreateur = id
);

CREATE VIEW tortue.projet AS (
	Select idProjet, _projet.idSujet, titre, description, outils, idCreateur, _projet.idGroupe, nomGroupe, idTuteur, tuteur.nom AS nomTuteur, tuteur.prenom AS prenomTuteur, sujet.login, sujet.nom, sujet.prenom
	FROM tortue._projet
	INNER JOIN tortue.sujet ON _projet.idSujet = sujet.idSujet
	INNER JOIN tortue._groupe ON _projet.idGroupe = _groupe.idGroupe
	INNER JOIN tortue.tuteur ON _projet.idTuteur = tuteur.id
);

CREATE TABLE tortue._annee (
	idAnnee Serial NOT NULL,
	debutProposition date NOT NULL,
	finProposition date NOT NULL,
	CONSTRAINT pk_annee PRIMARY KEY (idAnnee)
);

CREATE VIEW tortue.annee AS (SELECT * FROM tortue._annee);

CREATE TABLE tortue._tempgroupe (
	idcreateur integer NOT NULL,
	idinvite integer NOT NULL,
	CONSTRAINT fk_tempgroupe_crea FOREIGN KEY (idcreateur) REFERENCES tortue._utilisateur (id),
	CONSTRAINT fk_tempgroupe_invit FOREIGN KEY (idinvite) REFERENCES tortue._utilisateur (id)
);

CREATE OR REPLACE VIEW tortue.tempgroupe AS (SELECT idCreateur, id AS idInvite, login, nom, prenom, motDePasse, idAnnee, groupeClasse FROM tortue._tempgroupe INNER JOIN tortue.etudiant ON _tempgroupe.idinvite = etudiant.id);

CREATE TABLE tortue._invitation (
	idEtu Integer NOT NULL,
	idGroupe Integer NOT NULL,
	CONSTRAINT pk_invitation PRIMARY KEY (idEtu, idGroupe),
	CONSTRAINT fk_invitationEtu FOREIGN KEY (idEtu) REFERENCES tortue._etudiant (idEtu),
	CONSTRAINT fk_invitationGroupe FOREIGN KEY (idGroupe) REFERENCES tortue._groupe (idGroupe)
);

CREATE VIEW tortue.invitation AS (SELECT * FROM tortue._invitation);

--INSERT INTO tortue._annee (debutProposition, finProposition) VALUES (to_date('2020/10/30', 'YYYY/MM/DD'), to_date('2021/10/30', 'YYYY/MM/DD'));
--INSERT INTO tortue.sujet (titre, description, outils, idCreateur, idAnnee) VALUES ('Test1', 'Sujet de test 1', 'Nawak', 1, 0);
--INSERT INTO tortue.sujet (titre, description, outils, idCreateur, idAnnee) VALUES ('Test1', 'Sujet de test 1', 'Nawak', 1, 0);

/*
 *
 * TRIGGERS
 *
 *
*/

CREATE OR REPLACE FUNCTION tortue.add_etudiant () RETURNS TRIGGER AS $$
	DECLARE
		idEtu INTEGER;
	BEGIN
			INSERT INTO tortue._utilisateur (login, nom, prenom, motDePasse, idAnnee) VALUES ( NEW.login, NEW.nom, NEW.prenom, 'Lannion1', NEW.idAnnee ) RETURNING id INTO idEtu;
			INSERT INTO tortue._etudiant (idEtu, groupeClasse, avatar) VALUES ( idEtu, NEW.groupeClasse, NEW.avatar );

			RETURN NEW;
	END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER ajoutEtu
	INSTEAD OF INSERT
	ON tortue.etudiant
	FOR EACH ROW
	EXECUTE PROCEDURE tortue.add_etudiant();

-- INSERT INTO tortue.etudiant (login, nom, prenom, idAnnee, groupeClasse) VALUES('schtrmsi', 'Schtroumpf', 'Schtroumpf', 2020, 'B2');

CREATE OR REPLACE FUNCTION tortue.modif_etudiant () RETURNS TRIGGER AS $$
	DECLARE
	BEGIN
		IF OLD.id <> NEW.id OR OLD.login <> NEW.login OR OLD.idAnnee <> NEW.idAnnee THEN
			RAISE EXCEPTION 'Vous ne pouvez changer l´identifiant d´utilisateur ou son année.' USING ERRCODE='TORTUE_UPDATE_UTILISATEUR';
		END IF;

		UPDATE tortue._utilisateur SET nom = NEW.nom, prenom = NEW.prenom, motDePasse = NEW.motDePasse WHERE id = NEW.id;
		UPDATE tortue._etudiant SET groupeClasse = NEW.groupeClasse, avatar = NEW.avatar WHERE idEtu = NEW.id;

		RETURN NEW;
	END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER modifEtu
	INSTEAD OF UPDATE
	ON tortue.etudiant
	FOR EACH ROW
	EXECUTE PROCEDURE tortue.modif_etudiant();

-- UPDATE tortue.etudiant SET motDePasse = 'Schtroumpfette' WHERE id = 1;
-- UPDATE tortue.etudiant SET idAnnee = 2034 WHERE id = 1;

CREATE OR REPLACE FUNCTION tortue.suppr_etudiant () RETURNS TRIGGER AS $$
	DECLARE
	BEGIN
		DELETE FROM tortue._etudiant WHERE idEtu = OLD.id;
		DELETE FROM tortue._utilisateur WHERE id = OLD.id;

		RETURN OLD;
	END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER supprEtu
	INSTEAD OF DELETE
	ON tortue.etudiant
	FOR EACH ROW
	EXECUTE PROCEDURE tortue.suppr_etudiant();

-- DELETE FROM tortue.etudiant WHERE id = 1;

-- ********************************************************************************************************************************

CREATE OR REPLACE FUNCTION tortue.add_tuteur () RETURNS TRIGGER AS $$
	DECLARE
		idTuteur INTEGER;
	BEGIN
			INSERT INTO tortue._utilisateur (login, nom, prenom, motDePasse, idAnnee) VALUES ( NEW.login, NEW.nom, NEW.prenom, 'Lannion1', NEW.idAnnee ) RETURNING id INTO idTuteur;
			INSERT INTO tortue._tuteur (idTuteur) VALUES ( idTuteur );

			RETURN NEW;
	END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER ajoutTuteur
	INSTEAD OF INSERT
	ON tortue.tuteur
	FOR EACH ROW
	EXECUTE PROCEDURE tortue.add_tuteur();

-- INSERT INTO tortue.tuteur (login, nom, prenom, idAnnee) VALUES('schtrmsi', 'Schtroumpf', 'Schtroumpf', 2020);

CREATE OR REPLACE FUNCTION tortue.modif_tuteur () RETURNS TRIGGER AS $$
	DECLARE
	BEGIN
		IF OLD.id <> NEW.id OR OLD.login <> NEW.login OR OLD.idAnnee <> NEW.idAnnee THEN
			RAISE EXCEPTION 'Vous ne pouvez changer l´identifiant d´utilisateur ou son année.' USING ERRCODE='TORTUE_UPDATE_UTILISATEUR';
		END IF;

		UPDATE tortue._utilisateur SET nom = NEW.nom, prenom = NEW.prenom, motDePasse = NEW.motDePasse WHERE id = NEW.id;

		RETURN NEW;
	END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER modifTuteur
	INSTEAD OF UPDATE
	ON tortue.tuteur
	FOR EACH ROW
	EXECUTE PROCEDURE tortue.modif_tuteur();

-- UPDATE tortue.tuteur SET motDePasse = 'Schtroumpfette' WHERE id = 1;
-- UPDATE tortue.tuteur SET idAnnee = 2034 WHERE id = 1;

CREATE OR REPLACE FUNCTION tortue.suppr_tuteur () RETURNS TRIGGER AS $$
	DECLARE
	BEGIN
		DELETE FROM tortue._tuteur WHERE idTuteur = OLD.id;
		DELETE FROM tortue._utilisateur WHERE id = OLD.id;

		RETURN OLD;
	END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER supprTuteur
	INSTEAD OF DELETE
	ON tortue.tuteur
	FOR EACH ROW
	EXECUTE PROCEDURE tortue.suppr_tuteur();

-- DELETE FROM tortue.tuteur WHERE id = 1;

-- ********************************************************************************************************************************

CREATE OR REPLACE FUNCTION tortue.add_super_tuteur () RETURNS TRIGGER AS $$
	DECLARE
		idSuperTuteur INTEGER;
	BEGIN
			INSERT INTO tortue._utilisateur (login, nom, prenom, motDePasse, idAnnee) VALUES (NEW.login, NEW.nom, NEW.prenom, 'Lannion1', NEW.idAnnee) RETURNING id INTO idSuperTuteur;
			INSERT INTO tortue._super_tuteur (idSTuteur) VALUES (idSuperTuteur);

			RETURN NEW;
	END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER ajoutSuperTuteur
	INSTEAD OF INSERT
	ON tortue.super_tuteur
	FOR EACH ROW
	EXECUTE PROCEDURE tortue.add_super_tuteur();

-- INSERT INTO tortue.super_tuteur (login, nom, prenom, idAnnee) VALUES('schtrmsi', 'Schtroumpf', 'Schtroumpf', 2020);

CREATE OR REPLACE FUNCTION tortue.modif_super_tuteur () RETURNS TRIGGER AS $$
	DECLARE
	BEGIN
		IF OLD.id <> NEW.id OR OLD.login <> NEW.login OR OLD.idAnnee <> NEW.idAnnee THEN
			RAISE EXCEPTION 'Vous ne pouvez changer l´identifiant d´utilisateur ou son année.' USING ERRCODE='TORTUE_UPDATE_UTILISATEUR';
		END IF;

		UPDATE tortue._utilisateur SET nom = NEW.nom, prenom = NEW.prenom, motDePasse = NEW.motDePasse WHERE id = NEW.id;

	 RETURN NEW;
	END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER modifSuperTuteur
	INSTEAD OF UPDATE
	ON tortue.super_tuteur
	FOR EACH ROW
	EXECUTE PROCEDURE tortue.modif_super_tuteur();

-- UPDATE tortue.super_tuteur SET motDePasse = 'Schtroumpfette' WHERE id = 1;
-- UPDATE tortue.super_tuteur SET idAnnee = 2034 WHERE id = 1;

CREATE OR REPLACE FUNCTION tortue.suppr_super_tuteur () RETURNS TRIGGER AS $$
	DECLARE
	BEGIN
		DELETE FROM tortue._super_tuteur WHERE idSTuteur = OLD.id;
		DELETE FROM tortue._utilisateur WHERE id = OLD.id;

		RETURN OLD;
	END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER supprSuperTuteur
	INSTEAD OF DELETE
	ON tortue.super_tuteur
	FOR EACH ROW
	EXECUTE PROCEDURE tortue.suppr_super_tuteur();

-- DELETE FROM tortue.super_tuteur WHERE id = 1;

CREATE OR REPLACE FUNCTION tortue.suppr_sujet () RETURNS TRIGGER AS $$
	DECLARE
	BEGIN
		DELETE FROM tortue._inscrit_sujet WHERE idSujet = OLD.idSujet;
		DELETE FROM tortue._tuteur_volontaire WHERE idSujet = OLD.idSujet;
	END
	$$ LANGUAGE plpgsql;

CREATE TRIGGER supprSujet
	INSTEAD OF DELETE
	ON tortue.sujet
	FOR EACH ROW
	EXECUTE PROCEDURE tortue.suppr_sujet();

-- ********************************************************************************************************************************

CREATE OR REPLACE FUNCTION tortue.add_etu_tempgroupe () RETURNS TRIGGER AS $$
	DECLARE
		idEtuTempo INTEGER;
	BEGIN
		PERFORM idInvite FROM tortue._tempgroupe WHERE idInvite = NEW.idInvite;
		-- S’il n’est pas déjà invité par cette personne, l’ajoute dans son groupe temporaire d’invitations
		IF (NOT FOUND) THEN
			INSERT INTO tortue._tempgroupe (idCreateur, idInvite) VALUES (NEW.idCreateur, NEW.idInvite);
		END IF;

		RETURN NEW;
	END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER ajoutEtuTempGroupe
	INSTEAD OF INSERT
	ON tortue.tempgroupe
	FOR EACH ROW
	EXECUTE PROCEDURE tortue.add_etu_tempgroupe();

CREATE OR REPLACE FUNCTION tortue.modif_etu_tempgroupe () RETURNS TRIGGER AS $$
	DECLARE
	BEGIN
		RAISE EXCEPTION 'Vous ne pouvez modifier aucun n-uplet de cette relation.' USING ERRCODE='TORTUE_UPDATE_TEMPGROUPE';

		RETURN NEW;
	END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER modifEtuTempGroupe
	INSTEAD OF UPDATE
	ON tortue.tempgroupe
	FOR EACH ROW
	EXECUTE PROCEDURE tortue.modif_etu_tempgroupe();

CREATE OR REPLACE FUNCTION tortue.suppr_etu_tempgroupe () RETURNS TRIGGER AS $$
	DECLARE
	BEGIN
		DELETE FROM tortue._tempgroupe WHERE idCreateur = OLD.idCreateur AND idInvite = OLD.idInvite;

		RETURN OLD;
	END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER supprEtuTempGroupe
	INSTEAD OF DELETE
	ON tortue.tempgroupe
	FOR EACH ROW
	EXECUTE PROCEDURE tortue.suppr_etu_tempgroupe();

-- ********************************************************************************************************************************

CREATE FUNCTION tortue.ajouterEtuGroupe (idEtu INTEGER, idGroupe INTEGER) RETURNS TRIGGER AS $$
	DECLARE
	BEGIN
		INSERT INTO tortue._appartient_grp VALUES (idGroupe, idEtu);
	END
$$ LANGUAGE plpgsql;
CREATE OR REPLACE FUNCTION tortue.supprimerEtuGroupe (etuId INTEGER) RETURNS VOID AS $$
	DECLARE
		groupeId INTEGER := NULL;
	BEGIN
		-- Récupère l'identifiant de groupe de l'étudiant
		SELECT idGroupe INTO groupeId FROM tortue._appartient_grp WHERE idEtu = etuId;

	-- S'il est inscrit dans un groupe
		IF FOUND THEN
		-- Si le groupe n'a pas encore de projet
		PERFORM * FROM tortue._projet WHERE idGroupe = groupeId;

		IF NOT FOUND THEN
			-- Essaie de le supprimer de son groupe
			DELETE FROM tortue._appartient_grp WHERE idEtu = etuId;

			-- Si le groupe est maintenant vide
			PERFORM * FROM tortue._appartient_grp WHERE idGroupe = groupeId;

			IF NOT FOUND THEN
				-- Trois choses à faire si le groupe est vide :
				DELETE FROM tortue._invitation WHERE idGroupe = groupeId;
				DELETE FROM tortue._inscrit_sujet WHERE idGroupe = groupeId;
				DELETE FROM tortue._groupe WHERE idGroupe = groupeId;
			END IF;

			ELSE
				RAISE EXCEPTION 'Impossible de désinscrire un étudiant d’un groupe associé à un projet.';
			END IF;
		ELSE
			RAISE EXCEPTION 'Cet étudiant n’a pas de groupe.';
		END IF;
	END
$$ LANGUAGE plpgsql;

-- SELECT tortue.supprimerEtuGroupe(2); -- Non en groupe (ERREUR)
-- SELECT tortue.supprimerEtuGroupe(7); -- En groupe, sans projet
-- SELECT tortue.supprimerEtuGroupe(10); -- En groupe, avec projet (ERREUR)

